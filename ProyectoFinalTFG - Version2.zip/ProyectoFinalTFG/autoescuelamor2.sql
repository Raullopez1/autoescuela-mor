-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-05-2025 a las 12:38:51
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `autoescuelamor2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clase_comprada`
--

CREATE TABLE `clase_comprada` (
  `id` bigint(20) NOT NULL,
  `usuario_dni` varchar(255) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clase_practica`
--

CREATE TABLE `clase_practica` (
  `id_clase` int(11) NOT NULL,
  `DNI_alumno` char(9) DEFAULT NULL,
  `DNI_profesor` char(9) DEFAULT NULL,
  `matricula` char(10) DEFAULT NULL,
  `fecha` int(11) DEFAULT NULL,
  `estado` enum('DISPONIBLE','RESERVADA','OCUPADA') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `coche`
--

CREATE TABLE `coche` (
  `matricula` char(10) NOT NULL,
  `modelo` varchar(10) DEFAULT NULL,
  `marca` varchar(10) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `id_comentario` int(11) NOT NULL,
  `DNI_usuario` char(9) DEFAULT NULL,
  `comentario` varchar(255) DEFAULT NULL,
  `valoracion` int(11) NOT NULL,
  `megusta` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`id_comentario`, `DNI_usuario`, `comentario`, `valoracion`, `megusta`) VALUES
(2, '11111111A', 'hola me encanta', 3, 0),
(3, '11111111A', 'hola', 5, 0),
(4, '11111111D', 'hola caracola', 3, 0),
(5, '11111111A', 'dfsdfdf', 2, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pregunta`
--

CREATE TABLE `pregunta` (
  `id_pregunta` int(11) NOT NULL,
  `pregunta` varchar(255) DEFAULT NULL,
  `respuesta0` varchar(255) DEFAULT NULL,
  `respuesta1` varchar(255) DEFAULT NULL,
  `respuesta2` varchar(255) DEFAULT NULL,
  `respuestaCorrecta` int(11) DEFAULT NULL,
  `imagen` longblob DEFAULT NULL,
  `id_test` int(11) DEFAULT NULL,
  `puntuacion` int(1) DEFAULT NULL,
  `respuesta_correcta` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pregunta`
--

INSERT INTO `pregunta` (`id_pregunta`, `pregunta`, `respuesta0`, `respuesta1`, `respuesta2`, `respuestaCorrecta`, `imagen`, `id_test`, `puntuacion`, `respuesta_correcta`) VALUES
(1, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 1, 1, NULL),
(2, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 1, 1, NULL),
(3, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 1, 1, NULL),
(4, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 1, 1, NULL),
(5, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 1, 1, NULL),
(6, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 1, 1, NULL),
(7, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 1, 1, NULL),
(8, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 1, 1, NULL),
(9, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 1, 1, NULL),
(10, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 1, 1, NULL),
(11, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 1, 1, NULL),
(12, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 1, 1, NULL),
(13, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 1, 1, NULL),
(14, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 1, 1, NULL),
(15, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 1, 1, NULL),
(16, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 1, 1, NULL),
(17, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 1, 1, NULL),
(18, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 1, 1, NULL),
(19, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 1, 1, NULL),
(20, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 1, 1, NULL),
(21, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 1, 1, NULL),
(22, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 1, 1, NULL),
(23, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 1, 1, NULL),
(24, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 1, 1, NULL),
(25, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 1, 1, NULL),
(26, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 1, 1, NULL),
(27, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 1, 1, NULL),
(28, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 1, 1, NULL),
(29, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 1, 1, NULL),
(30, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 1, 1, NULL),
(31, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 2, 1, NULL),
(32, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 2, 1, NULL),
(33, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 2, 1, NULL),
(34, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 2, 1, NULL),
(35, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 2, 1, NULL),
(36, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 2, 1, NULL),
(37, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 2, 1, NULL),
(38, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 2, 1, NULL),
(39, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 2, 1, NULL),
(40, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 2, 1, NULL),
(41, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 2, 1, NULL),
(42, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 2, 1, NULL),
(43, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 2, 1, NULL),
(44, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 2, 1, NULL),
(45, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 2, 1, NULL),
(46, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 2, 1, NULL),
(47, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 2, 1, NULL),
(48, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 2, 1, NULL),
(49, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 2, 1, NULL),
(50, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 2, 1, NULL),
(51, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 2, 1, NULL),
(52, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 2, 1, NULL),
(53, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 2, 1, NULL),
(54, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 2, 1, NULL),
(55, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 2, 1, NULL),
(56, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 2, 1, NULL),
(57, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 2, 1, NULL),
(58, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 2, 1, NULL),
(59, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 2, 1, NULL),
(60, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 2, 1, NULL),
(61, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 3, 1, NULL),
(62, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 3, 1, NULL),
(63, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 3, 1, NULL),
(64, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 3, 1, NULL),
(65, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 3, 1, NULL),
(66, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 3, 1, NULL),
(67, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 3, 1, NULL),
(68, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 3, 1, NULL),
(69, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 3, 1, NULL),
(70, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 3, 1, NULL),
(71, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 3, 1, NULL),
(72, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 3, 1, NULL),
(73, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 3, 1, NULL),
(74, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 3, 1, NULL),
(75, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 3, 1, NULL),
(76, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 3, 1, NULL),
(77, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 3, 1, NULL),
(78, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 3, 1, NULL),
(79, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 3, 1, NULL),
(80, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 3, 1, NULL),
(81, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 3, 1, NULL),
(82, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 3, 1, NULL),
(83, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 3, 1, NULL),
(84, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 3, 1, NULL),
(85, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 3, 1, NULL),
(86, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 3, 1, NULL),
(87, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 3, 1, NULL),
(88, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 3, 1, NULL),
(89, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 3, 1, NULL),
(90, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 3, 1, NULL),
(91, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 4, 1, NULL),
(92, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 4, 1, NULL),
(93, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 4, 1, NULL),
(94, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 4, 1, NULL),
(95, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 4, 1, NULL),
(96, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 4, 1, NULL),
(97, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 4, 1, NULL),
(98, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 4, 1, NULL),
(99, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 4, 1, NULL),
(100, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 4, 1, NULL),
(101, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 4, 1, NULL),
(102, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 4, 1, NULL),
(103, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 4, 1, NULL),
(104, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 4, 1, NULL),
(105, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 4, 1, NULL),
(106, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 4, 1, NULL),
(107, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 4, 1, NULL),
(108, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 4, 1, NULL),
(109, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 4, 1, NULL),
(110, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 4, 1, NULL),
(111, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 4, 1, NULL),
(112, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 4, 1, NULL),
(113, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 4, 1, NULL),
(114, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 4, 1, NULL),
(115, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 4, 1, NULL),
(116, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 4, 1, NULL),
(117, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 4, 1, NULL),
(118, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 4, 1, NULL),
(119, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 4, 1, NULL),
(120, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 4, 1, NULL),
(121, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 5, 1, NULL),
(122, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 5, 1, NULL),
(123, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 5, 1, NULL),
(124, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 5, 1, NULL),
(125, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 5, 1, NULL),
(126, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 5, 1, NULL),
(127, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 5, 1, NULL),
(128, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 5, 1, NULL),
(129, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 5, 1, NULL),
(130, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 5, 1, NULL),
(131, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 5, 1, NULL),
(132, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 5, 1, NULL),
(133, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 5, 1, NULL),
(134, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 5, 1, NULL),
(135, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 5, 1, NULL),
(136, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 5, 1, NULL),
(137, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 5, 1, NULL),
(138, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 5, 1, NULL),
(139, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 5, 1, NULL),
(140, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 5, 1, NULL),
(141, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 5, 1, NULL),
(142, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 5, 1, NULL),
(143, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 5, 1, NULL),
(144, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 5, 1, NULL),
(145, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 5, 1, NULL),
(146, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 5, 1, NULL),
(147, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 5, 1, NULL),
(148, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 5, 1, NULL),
(149, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 5, 1, NULL),
(150, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 5, 1, NULL),
(151, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 6, 1, NULL),
(152, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 6, 1, NULL),
(153, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 6, 1, NULL),
(154, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 6, 1, NULL),
(155, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 6, 1, NULL),
(156, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 6, 1, NULL),
(157, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 6, 1, NULL),
(158, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 6, 1, NULL),
(159, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 6, 1, NULL),
(160, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 6, 1, NULL),
(161, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 6, 1, NULL),
(162, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 6, 1, NULL),
(163, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 6, 1, NULL),
(164, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 6, 1, NULL),
(165, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 6, 1, NULL),
(166, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 6, 1, NULL),
(167, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 6, 1, NULL),
(168, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 6, 1, NULL),
(169, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 6, 1, NULL),
(170, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 6, 1, NULL),
(171, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 6, 1, NULL),
(172, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 6, 1, NULL),
(173, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 6, 1, NULL),
(174, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 6, 1, NULL),
(175, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 6, 1, NULL),
(176, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 6, 1, NULL),
(177, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 6, 1, NULL),
(178, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 6, 1, NULL),
(179, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 6, 1, NULL),
(180, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 6, 1, NULL),
(181, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 7, 1, NULL),
(182, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 7, 1, NULL),
(183, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 7, 1, NULL),
(184, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 7, 1, NULL),
(185, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 7, 1, NULL),
(186, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 7, 1, NULL),
(187, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 7, 1, NULL),
(188, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 7, 1, NULL),
(189, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 7, 1, NULL),
(190, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 7, 1, NULL),
(191, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 7, 1, NULL),
(192, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 7, 1, NULL),
(193, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 7, 1, NULL),
(194, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 7, 1, NULL),
(195, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 7, 1, NULL),
(196, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 7, 1, NULL),
(197, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 7, 1, NULL),
(198, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 7, 1, NULL),
(199, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 7, 1, NULL),
(200, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 7, 1, NULL),
(201, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 7, 1, NULL),
(202, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 7, 1, NULL),
(203, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 7, 1, NULL),
(204, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 7, 1, NULL),
(205, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 7, 1, NULL),
(206, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 7, 1, NULL),
(207, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 7, 1, NULL),
(208, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 7, 1, NULL),
(209, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 7, 1, NULL),
(210, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 7, 1, NULL),
(211, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 8, 1, NULL),
(212, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 8, 1, NULL),
(213, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 8, 1, NULL),
(214, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 8, 1, NULL),
(215, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 8, 1, NULL),
(216, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 8, 1, NULL),
(217, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 8, 1, NULL),
(218, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 8, 1, NULL),
(219, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 8, 1, NULL),
(220, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 8, 1, NULL),
(221, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 8, 1, NULL),
(222, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 8, 1, NULL),
(223, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 8, 1, NULL),
(224, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 8, 1, NULL),
(225, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 8, 1, NULL),
(226, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 8, 1, NULL),
(227, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 8, 1, NULL),
(228, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 8, 1, NULL),
(229, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 8, 1, NULL),
(230, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 8, 1, NULL),
(231, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 8, 1, NULL),
(232, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 8, 1, NULL),
(233, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 8, 1, NULL),
(234, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 8, 1, NULL),
(235, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 8, 1, NULL),
(236, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 8, 1, NULL),
(237, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 8, 1, NULL),
(238, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 8, 1, NULL),
(239, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 8, 1, NULL),
(240, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 8, 1, NULL),
(241, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 9, 1, NULL),
(242, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 9, 1, NULL),
(243, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 9, 1, NULL),
(244, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 9, 1, NULL),
(245, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 9, 1, NULL),
(246, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 9, 1, NULL),
(247, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 9, 1, NULL),
(248, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 9, 1, NULL),
(249, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 9, 1, NULL),
(250, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 9, 1, NULL),
(251, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 9, 1, NULL),
(252, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 9, 1, NULL),
(253, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 9, 1, NULL),
(254, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 9, 1, NULL),
(255, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 9, 1, NULL),
(256, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 9, 1, NULL),
(257, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 9, 1, NULL),
(258, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 9, 1, NULL),
(259, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 9, 1, NULL),
(260, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 9, 1, NULL),
(261, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 9, 1, NULL),
(262, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 9, 1, NULL),
(263, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 9, 1, NULL),
(264, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 9, 1, NULL),
(265, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 9, 1, NULL),
(266, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 9, 1, NULL),
(267, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 9, 1, NULL),
(268, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 9, 1, NULL),
(269, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 9, 1, NULL),
(270, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 9, 1, NULL),
(271, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 10, 1, NULL),
(272, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 10, 1, NULL),
(273, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 10, 1, NULL),
(274, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 10, 1, NULL),
(275, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 10, 1, NULL),
(276, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 10, 1, NULL),
(277, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 10, 1, NULL),
(278, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 10, 1, NULL),
(279, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 10, 1, NULL),
(280, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 10, 1, NULL),
(281, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 10, 1, NULL),
(282, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 10, 1, NULL),
(283, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 10, 1, NULL),
(284, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 10, 1, NULL),
(285, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 10, 1, NULL),
(286, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 10, 1, NULL),
(287, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 10, 1, NULL),
(288, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 10, 1, NULL),
(289, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 10, 1, NULL),
(290, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 10, 1, NULL),
(291, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 10, 1, NULL),
(292, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 10, 1, NULL),
(293, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 10, 1, NULL),
(294, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 10, 1, NULL),
(295, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 10, 1, NULL),
(296, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 10, 1, NULL),
(297, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 10, 1, NULL),
(298, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 10, 1, NULL),
(299, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 10, 1, NULL),
(300, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 10, 1, NULL),
(301, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 11, 1, NULL),
(302, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 11, 1, NULL),
(303, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 11, 1, NULL),
(304, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 11, 1, NULL),
(305, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 11, 1, NULL),
(306, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 11, 1, NULL),
(307, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 11, 1, NULL),
(308, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 11, 1, NULL),
(309, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 11, 1, NULL),
(310, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 11, 1, NULL),
(311, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 11, 1, NULL),
(312, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 11, 1, NULL),
(313, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 11, 1, NULL),
(314, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 11, 1, NULL),
(315, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 11, 1, NULL),
(316, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 11, 1, NULL),
(317, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 11, 1, NULL),
(318, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 11, 1, NULL),
(319, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 11, 1, NULL),
(320, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 11, 1, NULL),
(321, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 11, 1, NULL),
(322, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 11, 1, NULL),
(323, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 11, 1, NULL),
(324, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 11, 1, NULL),
(325, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 11, 1, NULL),
(326, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 11, 1, NULL),
(327, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 11, 1, NULL);
INSERT INTO `pregunta` (`id_pregunta`, `pregunta`, `respuesta0`, `respuesta1`, `respuesta2`, `respuestaCorrecta`, `imagen`, `id_test`, `puntuacion`, `respuesta_correcta`) VALUES
(328, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 11, 1, NULL),
(329, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 11, 1, NULL),
(330, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 11, 1, NULL),
(331, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 12, 1, NULL),
(332, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 12, 1, NULL),
(333, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 12, 1, NULL),
(334, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 12, 1, NULL),
(335, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 12, 1, NULL),
(336, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 12, 1, NULL),
(337, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 12, 1, NULL),
(338, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 12, 1, NULL),
(339, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 12, 1, NULL),
(340, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 12, 1, NULL),
(341, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 12, 1, NULL),
(342, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 12, 1, NULL),
(343, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 12, 1, NULL),
(344, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 12, 1, NULL),
(345, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 12, 1, NULL),
(346, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 12, 1, NULL),
(347, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 12, 1, NULL),
(348, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 12, 1, NULL),
(349, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 12, 1, NULL),
(350, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 12, 1, NULL),
(351, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 12, 1, NULL),
(352, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 12, 1, NULL),
(353, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 12, 1, NULL),
(354, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 12, 1, NULL),
(355, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 12, 1, NULL),
(356, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 12, 1, NULL),
(357, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 12, 1, NULL),
(358, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 12, 1, NULL),
(359, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 12, 1, NULL),
(360, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 12, 1, NULL),
(361, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 13, 1, NULL),
(362, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 13, 1, NULL),
(363, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 13, 1, NULL),
(364, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 13, 1, NULL),
(365, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 13, 1, NULL),
(366, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 13, 1, NULL),
(367, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 13, 1, NULL),
(368, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 13, 1, NULL),
(369, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 13, 1, NULL),
(370, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 13, 1, NULL),
(371, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 13, 1, NULL),
(372, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 13, 1, NULL),
(373, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 13, 1, NULL),
(374, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 13, 1, NULL),
(375, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 13, 1, NULL),
(376, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 13, 1, NULL),
(377, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 13, 1, NULL),
(378, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 13, 1, NULL),
(379, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 13, 1, NULL),
(380, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 13, 1, NULL),
(381, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 13, 1, NULL),
(382, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 13, 1, NULL),
(383, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 13, 1, NULL),
(384, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 13, 1, NULL),
(385, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 13, 1, NULL),
(386, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 13, 1, NULL),
(387, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 13, 1, NULL),
(388, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 13, 1, NULL),
(389, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 13, 1, NULL),
(390, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 13, 1, NULL),
(391, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 14, 1, NULL),
(392, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 14, 1, NULL),
(393, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 14, 1, NULL),
(394, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 14, 1, NULL),
(395, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 14, 1, NULL),
(396, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 14, 1, NULL),
(397, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 14, 1, NULL),
(398, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 14, 1, NULL),
(399, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 14, 1, NULL),
(400, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 14, 1, NULL),
(401, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 14, 1, NULL),
(402, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 14, 1, NULL),
(403, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 14, 1, NULL),
(404, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 14, 1, NULL),
(405, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 14, 1, NULL),
(406, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 14, 1, NULL),
(407, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 14, 1, NULL),
(408, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 14, 1, NULL),
(409, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 14, 1, NULL),
(410, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 14, 1, NULL),
(411, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 14, 1, NULL),
(412, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 14, 1, NULL),
(413, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 14, 1, NULL),
(414, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 14, 1, NULL),
(415, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 14, 1, NULL),
(416, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 14, 1, NULL),
(417, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 14, 1, NULL),
(418, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 14, 1, NULL),
(419, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 14, 1, NULL),
(420, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 14, 1, NULL),
(421, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 15, 1, NULL),
(422, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 15, 1, NULL),
(423, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 15, 1, NULL),
(424, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 15, 1, NULL),
(425, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 15, 1, NULL),
(426, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 15, 1, NULL),
(427, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 15, 1, NULL),
(428, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 15, 1, NULL),
(429, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 15, 1, NULL),
(430, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 15, 1, NULL),
(431, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 15, 1, NULL),
(432, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 15, 1, NULL),
(433, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 15, 1, NULL),
(434, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 15, 1, NULL),
(435, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 15, 1, NULL),
(436, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 15, 1, NULL),
(437, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 15, 1, NULL),
(438, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 15, 1, NULL),
(439, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 15, 1, NULL),
(440, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 15, 1, NULL),
(441, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 15, 1, NULL),
(442, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 15, 1, NULL),
(443, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 15, 1, NULL),
(444, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 15, 1, NULL),
(445, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 15, 1, NULL),
(446, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 15, 1, NULL),
(447, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 15, 1, NULL),
(448, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 15, 1, NULL),
(449, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 15, 1, NULL),
(450, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 15, 1, NULL),
(451, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 16, 1, NULL),
(452, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 16, 1, NULL),
(453, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 16, 1, NULL),
(454, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 16, 1, NULL),
(455, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 16, 1, NULL),
(456, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 16, 1, NULL),
(457, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 16, 1, NULL),
(458, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 16, 1, NULL),
(459, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 16, 1, NULL),
(460, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 16, 1, NULL),
(461, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 16, 1, NULL),
(462, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 16, 1, NULL),
(463, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 16, 1, NULL),
(464, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 16, 1, NULL),
(465, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 16, 1, NULL),
(466, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 16, 1, NULL),
(467, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 16, 1, NULL),
(468, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 16, 1, NULL),
(469, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 16, 1, NULL),
(470, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 16, 1, NULL),
(471, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 16, 1, NULL),
(472, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 16, 1, NULL),
(473, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 16, 1, NULL),
(474, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 16, 1, NULL),
(475, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 16, 1, NULL),
(476, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 16, 1, NULL),
(477, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 16, 1, NULL),
(478, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 16, 1, NULL),
(479, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 16, 1, NULL),
(480, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 16, 1, NULL),
(481, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 17, 1, NULL),
(482, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 17, 1, NULL),
(483, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 17, 1, NULL),
(484, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 17, 1, NULL),
(485, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 17, 1, NULL),
(486, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 17, 1, NULL),
(487, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 17, 1, NULL),
(488, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 17, 1, NULL),
(489, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 17, 1, NULL),
(490, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 17, 1, NULL),
(491, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 17, 1, NULL),
(492, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 17, 1, NULL),
(493, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 17, 1, NULL),
(494, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 17, 1, NULL),
(495, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 17, 1, NULL),
(496, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 17, 1, NULL),
(497, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 17, 1, NULL),
(498, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 17, 1, NULL),
(499, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 17, 1, NULL),
(500, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 17, 1, NULL),
(501, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 17, 1, NULL),
(502, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 17, 1, NULL),
(503, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 17, 1, NULL),
(504, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 17, 1, NULL),
(505, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 17, 1, NULL),
(506, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 17, 1, NULL),
(507, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 17, 1, NULL),
(508, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 17, 1, NULL),
(509, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 17, 1, NULL),
(510, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 17, 1, NULL),
(511, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 18, 1, NULL),
(512, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 18, 1, NULL),
(513, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 18, 1, NULL),
(514, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 18, 1, NULL),
(515, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 18, 1, NULL),
(516, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 18, 1, NULL),
(517, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 18, 1, NULL),
(518, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 18, 1, NULL),
(519, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 18, 1, NULL),
(520, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 18, 1, NULL),
(521, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 18, 1, NULL),
(522, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 18, 1, NULL),
(523, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 18, 1, NULL),
(524, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 18, 1, NULL),
(525, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 18, 1, NULL),
(526, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 18, 1, NULL),
(527, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 18, 1, NULL),
(528, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 18, 1, NULL),
(529, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 18, 1, NULL),
(530, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 18, 1, NULL),
(531, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 18, 1, NULL),
(532, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 18, 1, NULL),
(533, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 18, 1, NULL),
(534, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 18, 1, NULL),
(535, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 18, 1, NULL),
(536, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 18, 1, NULL),
(537, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 18, 1, NULL),
(538, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 18, 1, NULL),
(539, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 18, 1, NULL),
(540, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 18, 1, NULL),
(541, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 19, 1, NULL),
(542, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 19, 1, NULL),
(543, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 19, 1, NULL),
(544, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 19, 1, NULL),
(545, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 19, 1, NULL),
(546, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 19, 1, NULL),
(547, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 19, 1, NULL),
(548, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 19, 1, NULL),
(549, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 19, 1, NULL),
(550, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 19, 1, NULL),
(551, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 19, 1, NULL),
(552, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 19, 1, NULL),
(553, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 19, 1, NULL),
(554, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 19, 1, NULL),
(555, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 19, 1, NULL),
(556, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 19, 1, NULL),
(557, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 19, 1, NULL),
(558, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 19, 1, NULL),
(559, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 19, 1, NULL),
(560, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 19, 1, NULL),
(561, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 19, 1, NULL),
(562, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 19, 1, NULL),
(563, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 19, 1, NULL),
(564, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 19, 1, NULL),
(565, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 19, 1, NULL),
(566, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 19, 1, NULL),
(567, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 19, 1, NULL),
(568, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 19, 1, NULL),
(569, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 19, 1, NULL),
(570, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 19, 1, NULL),
(571, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 20, 1, NULL),
(572, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 20, 1, NULL),
(573, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 20, 1, NULL),
(574, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 20, 1, NULL),
(575, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 20, 1, NULL),
(576, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 20, 1, NULL),
(577, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 20, 1, NULL),
(578, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 20, 1, NULL),
(579, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 20, 1, NULL),
(580, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 20, 1, NULL),
(581, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 20, 1, NULL),
(582, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 20, 1, NULL),
(583, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 20, 1, NULL),
(584, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 20, 1, NULL),
(585, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 20, 1, NULL),
(586, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 20, 1, NULL),
(587, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 20, 1, NULL),
(588, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 20, 1, NULL),
(589, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 20, 1, NULL),
(590, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 20, 1, NULL),
(591, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 20, 1, NULL),
(592, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 20, 1, NULL),
(593, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 20, 1, NULL),
(594, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 20, 1, NULL),
(595, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 20, 1, NULL),
(596, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 20, 1, NULL),
(597, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 20, 1, NULL),
(598, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 20, 1, NULL),
(599, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 20, 1, NULL),
(600, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 20, 1, NULL),
(601, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 21, 1, NULL),
(602, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 21, 1, NULL),
(603, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 21, 1, NULL),
(604, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 21, 1, NULL),
(605, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 21, 1, NULL),
(606, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 21, 1, NULL),
(607, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 21, 1, NULL),
(608, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 21, 1, NULL),
(609, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 21, 1, NULL),
(610, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 21, 1, NULL),
(611, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 21, 1, NULL),
(612, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 21, 1, NULL),
(613, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 21, 1, NULL),
(614, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 21, 1, NULL),
(615, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 21, 1, NULL),
(616, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 21, 1, NULL),
(617, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 21, 1, NULL),
(618, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 21, 1, NULL),
(619, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 21, 1, NULL),
(620, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 21, 1, NULL),
(621, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 21, 1, NULL),
(622, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 21, 1, NULL),
(623, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 21, 1, NULL),
(624, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 21, 1, NULL),
(625, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 21, 1, NULL),
(626, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 21, 1, NULL),
(627, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 21, 1, NULL),
(628, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 21, 1, NULL),
(629, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 21, 1, NULL),
(630, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 21, 1, NULL),
(631, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 22, 1, NULL),
(632, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 22, 1, NULL),
(633, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 22, 1, NULL),
(634, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 22, 1, NULL),
(635, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 22, 1, NULL),
(636, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 22, 1, NULL),
(637, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 22, 1, NULL),
(638, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 22, 1, NULL),
(639, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 22, 1, NULL),
(640, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 22, 1, NULL),
(641, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 22, 1, NULL),
(642, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 22, 1, NULL),
(643, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 22, 1, NULL),
(644, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 22, 1, NULL),
(645, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 22, 1, NULL),
(646, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 22, 1, NULL),
(647, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 22, 1, NULL),
(648, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 22, 1, NULL),
(649, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 22, 1, NULL),
(650, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 22, 1, NULL),
(651, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 22, 1, NULL),
(652, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 22, 1, NULL);
INSERT INTO `pregunta` (`id_pregunta`, `pregunta`, `respuesta0`, `respuesta1`, `respuesta2`, `respuestaCorrecta`, `imagen`, `id_test`, `puntuacion`, `respuesta_correcta`) VALUES
(653, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 22, 1, NULL),
(654, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 22, 1, NULL),
(655, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 22, 1, NULL),
(656, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 22, 1, NULL),
(657, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 22, 1, NULL),
(658, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 22, 1, NULL),
(659, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 22, 1, NULL),
(660, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 22, 1, NULL),
(661, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 23, 1, NULL),
(662, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 23, 1, NULL),
(663, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 23, 1, NULL),
(664, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 23, 1, NULL),
(665, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 23, 1, NULL),
(666, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 23, 1, NULL),
(667, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 23, 1, NULL),
(668, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 23, 1, NULL),
(669, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 23, 1, NULL),
(670, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 23, 1, NULL),
(671, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 23, 1, NULL),
(672, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 23, 1, NULL),
(673, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 23, 1, NULL),
(674, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 23, 1, NULL),
(675, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 23, 1, NULL),
(676, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 23, 1, NULL),
(677, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 23, 1, NULL),
(678, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 23, 1, NULL),
(679, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 23, 1, NULL),
(680, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 23, 1, NULL),
(681, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 23, 1, NULL),
(682, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 23, 1, NULL),
(683, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 23, 1, NULL),
(684, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 23, 1, NULL),
(685, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 23, 1, NULL),
(686, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 23, 1, NULL),
(687, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 23, 1, NULL),
(688, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 23, 1, NULL),
(689, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 23, 1, NULL),
(690, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 23, 1, NULL),
(691, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 24, 1, NULL),
(692, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 24, 1, NULL),
(693, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 24, 1, NULL),
(694, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 24, 1, NULL),
(695, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 24, 1, NULL),
(696, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 24, 1, NULL),
(697, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 24, 1, NULL),
(698, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 24, 1, NULL),
(699, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 24, 1, NULL),
(700, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 24, 1, NULL),
(701, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 24, 1, NULL),
(702, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 24, 1, NULL),
(703, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 24, 1, NULL),
(704, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 24, 1, NULL),
(705, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 24, 1, NULL),
(706, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 24, 1, NULL),
(707, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 24, 1, NULL),
(708, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 24, 1, NULL),
(709, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 24, 1, NULL),
(710, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 24, 1, NULL),
(711, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 24, 1, NULL),
(712, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 24, 1, NULL),
(713, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 24, 1, NULL),
(714, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 24, 1, NULL),
(715, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 24, 1, NULL),
(716, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 24, 1, NULL),
(717, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 24, 1, NULL),
(718, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 24, 1, NULL),
(719, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 24, 1, NULL),
(720, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 24, 1, NULL),
(721, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 25, 1, NULL),
(722, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 25, 1, NULL),
(723, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 25, 1, NULL),
(724, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 25, 1, NULL),
(725, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 25, 1, NULL),
(726, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 25, 1, NULL),
(727, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 25, 1, NULL),
(728, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 25, 1, NULL),
(729, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 25, 1, NULL),
(730, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 25, 1, NULL),
(731, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 25, 1, NULL),
(732, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 25, 1, NULL),
(733, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 25, 1, NULL),
(734, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 25, 1, NULL),
(735, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 25, 1, NULL),
(736, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 25, 1, NULL),
(737, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 25, 1, NULL),
(738, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 25, 1, NULL),
(739, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 25, 1, NULL),
(740, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 25, 1, NULL),
(741, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 25, 1, NULL),
(742, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 25, 1, NULL),
(743, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 25, 1, NULL),
(744, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 25, 1, NULL),
(745, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 25, 1, NULL),
(746, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 25, 1, NULL),
(747, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 25, 1, NULL),
(748, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 25, 1, NULL),
(749, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 25, 1, NULL),
(750, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 25, 1, NULL),
(751, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 26, 1, NULL),
(752, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 26, 1, NULL),
(753, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 26, 1, NULL),
(754, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 26, 1, NULL),
(755, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 26, 1, NULL),
(756, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 26, 1, NULL),
(757, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 26, 1, NULL),
(758, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 26, 1, NULL),
(759, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 26, 1, NULL),
(760, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 26, 1, NULL),
(761, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 26, 1, NULL),
(762, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 26, 1, NULL),
(763, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 26, 1, NULL),
(764, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 26, 1, NULL),
(765, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 26, 1, NULL),
(766, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 26, 1, NULL),
(767, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 26, 1, NULL),
(768, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 26, 1, NULL),
(769, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 26, 1, NULL),
(770, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 26, 1, NULL),
(771, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 26, 1, NULL),
(772, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 26, 1, NULL),
(773, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 26, 1, NULL),
(774, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 26, 1, NULL),
(775, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 26, 1, NULL),
(776, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 26, 1, NULL),
(777, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 26, 1, NULL),
(778, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 26, 1, NULL),
(779, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 26, 1, NULL),
(780, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 26, 1, NULL),
(781, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 27, 1, NULL),
(782, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 27, 1, NULL),
(783, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 27, 1, NULL),
(784, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 27, 1, NULL),
(785, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 27, 1, NULL),
(786, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 27, 1, NULL),
(787, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 27, 1, NULL),
(788, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 27, 1, NULL),
(789, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 27, 1, NULL),
(790, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 27, 1, NULL),
(791, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 27, 1, NULL),
(792, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 27, 1, NULL),
(793, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 27, 1, NULL),
(794, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 27, 1, NULL),
(795, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 27, 1, NULL),
(796, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 27, 1, NULL),
(797, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 27, 1, NULL),
(798, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 27, 1, NULL),
(799, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 27, 1, NULL),
(800, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 27, 1, NULL),
(801, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 27, 1, NULL),
(802, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 27, 1, NULL),
(803, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 27, 1, NULL),
(804, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 27, 1, NULL),
(805, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 27, 1, NULL),
(806, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 27, 1, NULL),
(807, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 27, 1, NULL),
(808, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 27, 1, NULL),
(809, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 27, 1, NULL),
(810, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 27, 1, NULL),
(811, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 28, 1, NULL),
(812, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 28, 1, NULL),
(813, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 28, 1, NULL),
(814, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 28, 1, NULL),
(815, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 28, 1, NULL),
(816, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 28, 1, NULL),
(817, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 28, 1, NULL),
(818, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 28, 1, NULL),
(819, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 28, 1, NULL),
(820, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 28, 1, NULL),
(821, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 28, 1, NULL),
(822, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 28, 1, NULL),
(823, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 28, 1, NULL),
(824, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 28, 1, NULL),
(825, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 28, 1, NULL),
(826, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 28, 1, NULL),
(827, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 28, 1, NULL),
(828, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 28, 1, NULL),
(829, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 28, 1, NULL),
(830, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 28, 1, NULL),
(831, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 28, 1, NULL),
(832, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 28, 1, NULL),
(833, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 28, 1, NULL),
(834, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 28, 1, NULL),
(835, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 28, 1, NULL),
(836, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 28, 1, NULL),
(837, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 28, 1, NULL),
(838, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 28, 1, NULL),
(839, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 28, 1, NULL),
(840, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 28, 1, NULL),
(841, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 29, 1, NULL),
(842, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 29, 1, NULL),
(843, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 29, 1, NULL),
(844, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 29, 1, NULL),
(845, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 29, 1, NULL),
(846, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 29, 1, NULL),
(847, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 29, 1, NULL),
(848, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 29, 1, NULL),
(849, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 29, 1, NULL),
(850, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 29, 1, NULL),
(851, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 29, 1, NULL),
(852, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 29, 1, NULL),
(853, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 29, 1, NULL),
(854, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 29, 1, NULL),
(855, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 29, 1, NULL),
(856, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 29, 1, NULL),
(857, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 29, 1, NULL),
(858, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 29, 1, NULL),
(859, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 29, 1, NULL),
(860, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 29, 1, NULL),
(861, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 29, 1, NULL),
(862, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 29, 1, NULL),
(863, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 29, 1, NULL),
(864, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 29, 1, NULL),
(865, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 29, 1, NULL),
(866, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 29, 1, NULL),
(867, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 29, 1, NULL),
(868, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 29, 1, NULL),
(869, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 29, 1, NULL),
(870, '¿Cuál es la tasa máxima de alcohol permitida en sangre para conductores nóveles?', '0.3 g/l', '0.5 g/l', '0.0 g/l', 0, NULL, 29, 1, NULL),
(871, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 30, 1, NULL),
(872, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 30, 1, NULL),
(873, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 30, 1, NULL),
(874, '¿Cómo se debe reaccionar ante un ciclista en la vía?', 'Respetar la distancia mínima de 1.5 metros', 'Pitar para avisar', 'Adelantar sin reducir velocidad', 0, NULL, 30, 1, NULL),
(875, '¿Cómo se debe estacionar en una pendiente ascendente sin bordillo?', 'Girar ruedas hacia la derecha', 'Girar ruedas hacia la izquierda', 'Dejar las ruedas rectas', 1, NULL, 30, 1, NULL),
(876, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 30, 1, NULL),
(877, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 30, 1, NULL),
(878, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 30, 1, NULL),
(879, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 30, 1, NULL),
(880, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 30, 1, NULL),
(881, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 30, 1, NULL),
(882, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 30, 1, NULL),
(883, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 30, 1, NULL),
(884, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 30, 1, NULL),
(885, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 30, 1, NULL),
(886, 'Si un peatón cruza fuera del paso de cebra, ¿quién tiene la prioridad?', 'El peatón', 'El vehículo', 'Depende de la situación', 2, NULL, 30, 1, NULL),
(887, '¿Qué indica una señal de STOP?', 'Detenerse completamente', 'Reducir velocidad', 'Ceder el paso si hay vehículos', 0, NULL, 30, 1, NULL),
(888, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 30, 1, NULL),
(889, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 30, 1, NULL),
(890, '¿Cuál es la distancia mínima de seguridad en carretera?', '50 metros', 'Depende de la velocidad', '100 metros', 1, NULL, 30, 1, NULL),
(891, '¿Cuál es la velocidad máxima permitida en una vía urbana?', '50 km/h', '30 km/h', '80 km/h', 0, NULL, 30, 1, NULL),
(892, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 30, 1, NULL),
(893, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 30, 1, NULL),
(894, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 30, 1, NULL),
(895, '¿Qué significa una señal triangular con un coche y líneas onduladas?', 'Peligro por hielo o nieve', 'Peligro por lluvia', 'Peligro por gravilla suelta', 0, NULL, 30, 1, NULL),
(896, '¿Cuándo puede utilizarse el carril bus?', 'Nunca', 'Solo si hay atasco', 'Si se circula en moto', 0, NULL, 30, 1, NULL),
(897, 'Si llueve, ¿cómo afecta a la distancia de frenado?', 'Disminuye', 'Aumenta', 'No cambia', 1, NULL, 30, 1, NULL),
(898, '¿Qué debe hacer si un semáforo está en ámbar fijo?', 'Detenerse siempre', 'Continuar si es seguro', 'Acelerar para cruzar', 1, NULL, 30, 1, NULL),
(899, '¿Quién tiene prioridad en una rotonda?', 'Los vehículos dentro de la rotonda', 'Los que van a entrar', 'Los peatones', 0, NULL, 30, 1, NULL),
(900, '¿Qué significa una línea continua en la carretera?', 'Que no se puede adelantar', 'Que se puede adelantar con precaución', 'Que solo se aplica a camiones', 0, NULL, 30, 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resultado_test`
--

CREATE TABLE `resultado_test` (
  `ID_resultado` int(11) NOT NULL,
  `DNI_alumno` char(9) DEFAULT NULL,
  `id_test` int(11) DEFAULT NULL,
  `puntuacion` int(2) DEFAULT NULL,
  `numeroFallos` int(2) DEFAULT NULL,
  `numeroCorrectas` int(11) DEFAULT NULL,
  `esAprobado` tinyint(1) DEFAULT NULL,
  `es_aprobado` bit(1) DEFAULT NULL,
  `numero_correctas` int(11) DEFAULT NULL,
  `numero_fallos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resultado_test`
--

INSERT INTO `resultado_test` (`ID_resultado`, `DNI_alumno`, `id_test`, `puntuacion`, `numeroFallos`, `numeroCorrectas`, `esAprobado`, `es_aprobado`, `numero_correctas`, `numero_fallos`) VALUES
(1, '11111111A', 1, 0, NULL, NULL, NULL, b'0', 0, 30),
(2, '11111111A', 1, 0, NULL, NULL, NULL, b'0', 0, 30);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `test`
--

CREATE TABLE `test` (
  `id_test` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `test`
--

INSERT INTO `test` (`id_test`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25),
(26),
(27),
(28),
(29),
(30);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `dni` varchar(255) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `apellido1` varchar(255) DEFAULT NULL,
  `apellido2` varchar(255) DEFAULT NULL,
  `Edad` int(2) DEFAULT NULL,
  `rol` enum('ALUMNO','ADMIN','PROFESOR') NOT NULL,
  `localidad` varchar(255) DEFAULT NULL,
  `correo` varchar(255) DEFAULT NULL,
  `contraseña` varchar(255) DEFAULT NULL,
  `Telefono` int(9) DEFAULT NULL,
  `imagen` longblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`dni`, `nombre`, `apellido1`, `apellido2`, `Edad`, `rol`, `localidad`, `correo`, `contraseña`, `Telefono`, `imagen`) VALUES
('11111111A', 'Raul', 'Lopez', 'Portoles', 19, 'ALUMNO', 'Estada', 'raul@gmail.com', '1', 666666666, 0xffd8ffe000104a46494600010100000100010000ffdb00840009060712121215101012151515171515151715171515151515151515161715151515181d2820181a251b151521312125292b2e2e2e171f3338332d37282d2e2b010a0a0a0e0d0e1a10101a2d2520252d2d2d2d2b2d2d2d2d2d2d2d2d2d2d2d2b2d2b2b2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2dffc0001108011300b703012200021101031101ffc4001c0000010501010100000000000000000000010002030405060708ffc400411000010302040305060402070900000000010002110304051221314151610622718191071332a1b1c1234252f072d124626392a2b2f114153343547382e1e2ffc400190101010101010100000000000000000000000103020405ffc40026110101000203000201030501000000000000010211032131124161132232041451819123ffda000c03010002110311003f00ec92461285f2df40d493a104012452401029c8206a09c81503524504012452401245240104e41004139250361084f842114c845184505949184a1748092309206c208a450041140a00534959f8e62f4ed699a955d1c87127a05e778d76f6b556e5a20d2699198197103ac777cb55d6385cbc7396531f5e9d52b344e6204732069cd414b12a2e9cb518e8d0c38182bc26eab17ce72f799d41738cc4c3bbdbf18f15038332c8106666608e8b5fedff002cbf5ff0fa1c145782e1fda9bbb7d2957740fcaeef34f91fb2efbb2ded129d770a5721b49e740e07f0dc7949f87cd67970e58f6ef1e5c72e9dea49a0a7059b414a1208a0108427c21081b0827425081a9230929a169246125d20248a081a814e4d28a69599da0c669da52356a6bc1ad044bddc0095a6578b76cb1575cdcd476a58c3eee9892006b49970eae7027c23a2ef0c3e55c6797c633b1bc5eadd54754ac49de193dd600760361f759a1c632e58913a1d81da20fee7a2b14ad2a38670dd00d74d00e077d38ea53d96351f4dcea6d25800248698113bb88ebfbd97ae593a79ae395ed44d4d818807d0f13bef10a173b5ef6c7498d7c4296a496987469a6b1987281ba36986d47b0b80d04c93e0bab64f5ccc6dea2abce91e247f22a2255a7583ff0049fdfeca88d07722acb12cb3d7a1fb3bed9905b6774fd0e94aa38ec785371fa1f25ea217ccc74d085ebfecdbb542bd316b59df8cc1dd24eb51836f1701e6409e6bcbcdc5afdd1e8e2e4df55de04e4d6a72c1b92508a4802109c8206c249c920b09422922042109c920614d29e535c8ae5fb7f891a168e2c716b9ee0c0e0608dcba3c9a479af2cecde1eeb9a829c90266664003ea574ded4b12f7959b6a36a6d2e7757bc0fa37fcc54becf2d435d320e9c36df82df1fdb86d9ebe59ebfc3a5b3ecad1690e7b43cb74683b0133af3d56b7fbad8691a45b2d7032239eeafd26e8a50565236b93cadfd85f7750f74b84fc45c223f8409d574167853698203601e1007c97575db3ac2cdba6eab9cedbed7586a791cf5c58b1a086b5a01e00013e2b8ac66d00260715dedeb97238bb676eab8c32b2b4cb1971713776c419e0a2a159cc707b1c5ae6904386e08d885b57b4f4216111aafa3865f29dbe5f2e1f1bd3e85ecae29fed56b4abf1737bc393dbdd70f5056c00b8ef6543fa033fee558fef95d980bc594d5b1ebc6ee4a1094228c28a6c2509c8206c249c424825451491012450400a6394881083c8bdabdb86dcb1e2417d2d7a96b88dfc216b7b37b52da06b3c800e83a06ee49fdec9ded6ed01652ac35c85cc7741500824f8b7e6adf608075931aff865e3cb3110b5b7ff0038e709aceaf56ed239d0db6a66a0982e8765f2806554abdafab44e5af6a67810481eae0b52ff00161440a76f6efa840fc8d3944709da57158af6a2f5d55b4c520ccd339d8e86c12049220c800e9faa131f3a7794efb7778363ccb8d98e6189870d0f81ff004525e39ad993b0597d91ba7d6607d56b4198d011b7458fed171675180cfcd2171bf93af8fc6a1c67b536b4c964b89d8c37eeb94bcc7e83b56074f54bb3b4e8566d4ab5e9078a705d2eca049805c4e91299738bd9bdb0cb614c6c0c0f9c715afe9c9f559fea5be6514fde35e641fdf5597754da1c752b4a8d166696711b2cec57fe21f01f45a71dfdda8c7965f8eebd9bd98d2cb87d2e45d51c0f305e755d7058fd93b2346cede938416d2648e44893f3256d05e5caeedadf1ea400124e84a140d493a1040d413e10454c92484220a09654a1024914106655b4654f7ec7b41cd941fe1c9f49958dd8dc38d3b765327e12f1fe372df826a12d8896870e2401a47992996900903f53bfcc6531f1a657eff08aee8b9bab0eab32a587bf3f8a5c6384c7d003f35d2d6cb9093c173563883aa572ca425acf89dc27834755d65355d61772fe1a96f6eda6035a200d82f3df6a43566860caf47655666caf76bcb8fa2e3bda355a429c13de27bbd124d595cdfb8e0fb36ead4e7ddead3bb4b4387a15d05de07efdb98b98ce603434fa15cde078b1a359a0f79ae307a4f15ea973401a5206842eb9372ece3f8dc74f29bab46d2395a6483baa66cbded6209868893e5b05ab8bd38a87c556acef76e6541324811c08ca2647a2ea657fdb8cb096eaf8f44f65b7d52a53acd7925ac780d924c483224f805dd85cb7b39b6cb64d3119df51dd48ce5a27c9aba9cab2beae7ef428a108a8e41245240d491ca9207a494a481248a0884925284aa006c6b025671043dc3a93ebafdd69aa374cefcf303e5a295d6358fda3bd73436930e52f997706307c4e8e2760073213b02a94dac0da2c7651273104499325c4f12654f754c39edd24c39b3cb63f65875b05af49f22b3df4358a44c06920c0cd04900c687aab8f75a7d69bb5aede2486b1d3c9d3f65e79dadb26d67667d4748fc93a34aefa9b68805b2038b65bdeaa44ece0496c37a713aae7319c2690caf2f3fda41a84939a21a052d4446be2577f1beca932c7b994bff1e7f6b49b45f2e6e600ee083a73e8bbcc231ea75986930f7837301c4b46fe92b81bfb7767018edc99712606a7482013fbe7a773845bd0a3485671efb5aeef682644440f14e5d6b7f661b9d6ba71d89bff0015d3c0ab8dc2ae5d0f6d1a85a4775c29b9c1c3690405585235aac37773801e6400bdc6d280a6c6531b31ad68f06803eca5ba4f977b677646c9f46d28d2a808735a641dc4b8983eab65009cb8736ec12450472492529268d9249228a72492481249248849249204abde325b2371af88e215809b5763e07e88acda64182ac900e8750b3ef0960ce048dc81f551e1d8bb2a8cb3aec751bf5e4ae2ee8e20d2d6e56b5ae1fd61afaf10b95c56bd72d2da74dadd373afa2edeb53eec93e0b0712d1a4b40f24cb6d78f3fa7989b0797c99277252bfbd240a60e834f15ab8d6241ac206e773c8725cc5b550e249e6b4c65ca6eb1e4b25d4769ecfac83ae985df9439f1d40d0fa907c97ac2f2ef66ef9bbf1a6ffb2f5259df4c81145251c9249230aa0248c24802492481c842724a29b0942292bb4d0248a0a050a2b9f85de1f553b584ec162d7c45eeacea2d637ddb742fcc7317b5c439b963482dde788eb17575b59ddd2c35b2217218df67df4de6bda6f32e613034fd3a68bb26b536a23b79e3fb59558df775a93c384eb1234dd655df6b65a406bb5e11d177f8a59d37025e042f3fc5ac5a49c8344971df71d6b2d755cc5cd5754399cd8f1fe49f43a3442d4b4c30bcab6ec2b2eab5bcb3c678f0ddeeb4fb01522f29f0cc1edff038fd405eb0bc4a85cba8bc54618734c83d576dd8dedabee1f5295d35ad2c6878a8c0402d2488737583a70596adedd67d3b884a1368d56bc666904730654908cc0044045244240a2922984249c504419452440e4a3a040a95b4b9e8a56b00e0b4c78b2acf2e4915802a56d2813b9e4a7b770d4394c5806db2db1e2c632bc96a16c4b48da608e460ac0b9b6cb55ffc45dfdf39a7e6ba47c11c8fdc2a58b50902ab44c08701be5e63991ae9d4f44e5c77178b3f8e4cd6a0f129dc246b3f350bcc2f33d5ea8e21699810b9bbdc2a341b7a2eb2b54d16656a25c65715a636c665b58329b565620775b77ce8d02cca9684ea571b691cc5e5b3b70ba8ec6604e653355c21f5a2072a6df809f125c7c085a184f673de1152ab7b9321bfafff009faaebdb4201e647a2f6716375baf17f51c937a8c6b5a4ea6efc331000f18e6b5a85f1fce3cc7f2469d04ff72b4b84ac26762cb1e0ea0ca74aa26911a8d139b7441878d39858e5c7678d31e497d5b94a5063c1d4194e59b4049249153368f3f45201c02b6ea6a2c9c97af1c263e3cb96772f4d6b107534eef04f6d4e6ba70832273415625054468b5d093826c1419f77873812fa3041d4d33a09e258781e9b1e9aaceacf07420b5dc5ae10ef43b8ea345d0ea9b5a987087b438722011e8565971cbe36c39acf5cd35b298eb6d256fb2c69b76601ea3e49fee06c1a3d3f9acff46b5fee27d47194f0e7547775a4f53b0f35b56b823041a9de2387e5f4e2b6830a418bbc3871c7d679ff0051965d4e900a698f1a9564b544e6ad5822013a118480450ca98fa4a58294268503420cb4c27b6e48f884f5e2ad3d8a0a8c5c5c65f5d4cac4b4ea0709051598e6b9a65a52595e2ad67247630aa513a96f22ace6d5567e953c42f4d79d310a32d5294c25030044a52812812091282048145365014120522540d29145040d2131cd5214d282170413dc98503822131c74473435012147519a13c93c3b494efc84a0cc7bc00094550a4ff79a706883d4f0fe7e8922bb6cbaaaef6cbdbe0a663d46cde794fd5544ae4c213c26b90465a984290a6140d2913a20f28573002033a2509af3a22c280e5d10ada405291a2ad50cd403a209a13613dc3541c140c84c2d5204c2818e098e12a42a37184113cf04aa9d0a7546e61d556655d7239048ef80f51296355fdddbb9e3969e69941da86a8bb50e8b6cbcdcd1e8509eb330367e1c9dc993e692185ba299f184916bb00eef11cf54676f150d5743c1533778ea7f9a0b198ef0a20e2758d132edfab698e3bf80dd4afd040550d253538a68410d43de851ddbb609ed32e515ebbbc1039ee4fb6d54358ecac598413b950a4e9aa7a057ea159b627bef3d505e24f24d71e8a429ae40c4c7a714dabb281a4a85e54a0e8a0aaf82822754851e20c101db26dc3a35599dabbef774a8b871ad48791709f94a5234ac2a8ce01de3454fb65761ac683ce7e454d4a9fe3b08d867f4810b96f69970486306ee7e4f507752bac676d3c135b761fd64bbc8ea1257b0ba10d633835807c92552ba0bc3c792b341d395cb2cd6ccc0ee63fd558a150b6983ce63c0953625b7a99ab38f210ae8fd4567e10cd1cee24ad12382b0a6941c61a4a2e628ae8690aa23b6e6ab620eef3559a5a4054f1430f6281d58eab42d468b35a25c16ad2668a865776eb3ac3e22addd6c553b2f88a0d429853d35c821721536408d532a0d0a821a6ed156c51f0c0ee4e1e89ec744a8b136e6a242082ad6ef01c0e8b9af681572dab39b6b37e41caed2b99cb3b83aaa1ed0cff4507fb467d0a97c75276ea2c6e5ae632b0d73301f50172fda6a3ef1f45e7fea07a069fbad2ec7d6cd62c71e008f2692a8f6c6e3dc51a6e3f14981fd673493f552f8b26aba7c2dba177924a0c2ea65b5a65c752d04f9a4aedce9054ac585f4cf0248f03bfce56b36e854a4d70fe18e45ba11f254b1cb719b385260a01a0c8fd4ff00f395cfde9ddf36dcb06c3159054344c353f32d1c1eaadd3f58561ab32e1f2e2889a86aef0553183df1d16859b604acac4df2f52916ec5b3aad4e0a8d88d15e2a8a578555b4dd4d785434342a0d36941c9949e9567e8551083329b50e8a2b57c83e2a47eca0cfa8e4b34b5c3a2a42e33170e454b46a7c47a20c4bf706873b62083e2b37b6d533d8e61c1d4cff008a3eeaee3a7f0dde03ecaa6214b35855075fc3cc3ff1ef0fa2e6b4883b3d8f53b6b2a4da924baa383583573ce61dd68e3a1f0d53bb6c6a5c7fb3512c02abdee764692ecad88d4f989f35c4e1d741d5ed9ceff959b5f120fd57a4f66bbe6a5fd4d4919290fd34c72eae327cc293be9d59abb6bd2a5a3697063403e20420addb5321b27776a525d6996cb107e66f9150f63ea9c9518766be4783b71ea3e69b506fd56961f445301a3cfa92b3b96b28d663bc6b5e99d13935a1382d58954300ac8a4333bcd685f5486a830ca3c4a2af1d1ab9fabdeabe6b6efea43564e194a5c5e7c0251b16ed80a4720dd90a8745519b76754e60d932beae0a6234504b48a96b6c556a45597ec831ed9f0f2d57aa0d164debb2540eeb1eab5a6422b8e73f25533b3a42d71f09f0593da0a704b87032ae61f719e9cf4522df36c6ed07c040e20051e215db4adb238fc54dc3c6410ac62d4e5cdf2ffd2c5c62d1d737b4eddb395ac6e63fa444b8f8c103c485c6575db5c66fa71f8861efa1468d7263defbdca3906b9ad07ce49f085e9fd9519ada8b38403e8aee3180d1b8a3ee1cd0034014c80269902010ab764e9b98d149e21cc9691e07e8b3e3cf75d72e3a8e91e1245c92f43ceab68353e015d6a492f267ebd78f8d1a4745204525eb7919b88b95bb3f851495fb452c5dc6149868ee8f045253ed57b8286b94925519ef3de1fbe2ac03a24928194f7f3577820920e771bdbc9695b38e51e09248ac2c747c5fc2b33b3ae3047041253edd4fe29b10ddbe5f74bb3cc1efae5f1decec6cf40c1a2292c797c6dc5eb78150347e34f368fa949259f17f275c9fc6b4d8d0504925eb795fffd9),
('11111111B', 'Agustin', 'Bordillo', 'Pi', 32, 'PROFESOR', 'Alcolea del cinca', 'agus@gmail.com', '1', 666666667, 0xffd8ffe000104a46494600010100000100010000ffdb0084000a070816151518161616181818191918181a1c181a1818181818181a191a1a1a18181c212e251c1e2b2118182638262b2f313535351a243b403b343f2e343531010c0c0c100f101e12121c342124213431343434313134343434343431343434343134343434343434343134343434343434343434343134343431343434343431ffc0001108011300b703012200021101031101ffc4001b00000105010100000000000000000000000002030405060107ffc4003b10000201020404030604030803000000000102000311040512210631415113617122328191a1b14252c1f01523d114243362728292e116d2f1ffc4001801010101010100000000000000000000000001020304ffc4001f1101010002030101010101000000000000000102111221314103516113ffda000c03010002110311003f00281d87a08eb191d3602fda2a9d50794e6e8c87126135d54079132df0dc394b48baf491339c2b3564206c0ef2eb14e5296dcc096a4770d854a2bec8023787cc91c95b8ed30d8cce9c9652dd4caca78f656b826355771e9ef96d27372a09955c419622d33a540d8ca9e1dcd59deccdda6a33ac29a8961d44222f0ba1f0c5fb4bc6a7e72b724c21a6963240c58d5626458aee274fe59f4320f0ae0519012a0ed2ef36c378a961d6319265e69258c7c35da58c1d3537b2890f139ba23693699ae27c7ba380ac79ccb56c5331b932c8972d3d5c57a6e372229f0e854d94729e5f87cc5c586a3cc4f48c9df5d3e77b88f177b65702806298016d87de6d1dac04a7a5929158bf792738c4aa2f38a913df743e931d95aff7a7bf97eb34f9556574e7d247c3e4e12a971d79c153abba27bc0095b8fce5117d92247e2dc4a8422fbda79f35427acb216e9e8d96e78187b5b4279da5765e4611c69b8f40e27cd1a9ad941f594fc379c3b3e9209f3feb3675f049547b43633983cae9d3f714093a3bd96c2f6246f2ab88b10e108511cccf3308ea9dcda4bc6207a77b74915e4f59aec4c6e5863f0fa5dbd86e67a1b48a0adf6537ed3a399dcb598545d1ceff0049eab800c506a982e19c2378b72a40f39becc313e1a5c741319378f831a1821d33cf2be32bad7b6e4df6f313799363cd55b983e54a5f5698853995bb9405847f13a8a9b46334c57849703908ce499878cb7ef234f3bcfd5c553abe12ae6cf8b32d7660516fbcc9d7c2ba7bca44dc73b3b3137dc274df40b9da6530d95d47b1086d3d1325a1a29d88e424ab8a794bf5992e24ca6b39f64dc76925b326188d1bda6a29ee245f596e1acb2a531ed19a4d40ed7de3d53dd36ed32586c5b1c495b9b7fdc1e22718e5ed6d60ec37b4c64f57ce707e2269f2985c670f5445be9bdbb4b2a58a284b4c164b52a74b7af384bb4d57a961fdd5f411f511bc32d9403da3ca261b6338847f3d3fd5fa4d3e19d340171ca51f10e4ef5581424106f795e991e240f7dbe92d46a2a6069383b0bcadc1f0e53572c5447b24cbaa27bee5bd65b6c76bef229a51493b0903883149e19f6872321e65905476b8761e8642abc2751858bb1f8c16ac3847dc9a69559165668a05edb4b6bc13c527128fe59f4329b8531c8a962669f32c1f88963ca641b24c32358d655627906b9efd254fad41cc29136b888c46069d4dec3e529f059251d6ba6a066372006b9db9fa4d02844502f22fa609a7497a48ed9dd3008b892f13804acb2b0f092183b67d314af890419baa4e348f495184e184a6da801797694c016952073ec9f49e7f5b142962493c8cf42b4acc5e4a8e6e44151178929585c8961431295176dc1907ff001ba7d849829a51580b5a0a8090211383c6254bee210266b8dbbb0e51d46045e754c8d0a6c6dbc517917138c54e6647fe2c9dc405e3f14eaa74898dc2e775857d2c399da6ca9e351f6b8312994d3d5aec2f0962761ab3328263ba9a40c466494f62408cff001fa5f9842ad4334839b6629874d6e77e8a39b1ec230f9fd35467276517dba9e807999e718fcc1ebb96762493b5c9b283c801d072e52c8cdba4bcd73fad88e6da57a2a9b0f8f79130c40e8479dbf1797ef9484a7a77fa192a8e1d8d80b9b1b8b5c8bfa4df8cfa783b2b00ad737bec775e9b79f38bfedf56fa4b1b13bee7d3e1d22711846dbd8607fd2dce3d470eedb6924f98b1f835fe926e2eaae322ce58b68626c4d81e7f39b440d69e6f88c2d5417d16b75b8b9edeb34181e28f614383a80b1e6794cd9fc597e56a779df0cccd61788d5ea68135349ee2f229ad0611e7993cd33ef0df4efbf681a7947c4d8576a64a137b4ae6e25ff2b7c8cb9caf1a2aaee0fc65464787b0556ec49604f4309b84a016e408405600828be91fd323e0c69a6b7ed3984c5876207491a66b8c90ec01dc903e7159670deb4058c7b8ae833b26917f687de5f60414a43c84bf19fa8797e42b4cdc1967e2a5f4de63b33e2864764b199d39ed4d7aeff08d53723d131b922543726f2bf1dc388a84894d96f143b3aa9eb3695aef4bd448bd5795d60d7f0d790249f9da4bc2e485d82dced62dd85fa03d648c2d1fef2e08f74fefef34d4124cb2d751ac3097baa94e1304dc3903b117f919a3cb32a4a7c85fd63f86a779396858127a4ceed7698e31c7d06da941963835a1cb4807c80bc8ab8304738f53c3053b19619691b3cca11d2c2c0db623902371b4f3ad1e1bfb4391dc5be63ef3d5eb27b0660789f0c356a037ebf2ff00ecd4baba72cf1eb6afaf8745ae8c9f8b71e866e30dee0f4989cab0a6a696fc8c44daeb0882fda5ae789d3c8cc2e3a8ab62803e736586c52bec0ca3c56567c70f242ac932da6145c4e86a74c120c4e6cfa295efbda79a62b37aac48d5b5ccb26cb74f46c1e6c8e48b8da13cba962994dc13733b2f1a6e3d4b3ac60a54cedd264720cec8a84107da3b4dae2b0ab593d44a6cab86951f5192696ef6bf015c02446334c5e84200e93b8fcc168800d8748e35aa25fca457926615b53b13de4596fc4385d154d81b1f2951371ce9da154ab061d0de7ab70f62cbd3171d3acf32cb2933545014917edd27abe0c0a7481b721339358b2d570da7175cf20181ff009283fd62abe70a9b2217b733636f847ddfc57a8c0ec7403fed06ff00a48756a545f669a587e636b7df79cefaeb8ef8914b895d5bdaa6c3e066af2fc6355520751cfcfa4c39a35d9b76b9fa7d3e1371c2d872b60dcc9bc5ade32aa734cfaad16d2aa4b7223b48f84e26c5373420743b1f9ef2ef8e3286d62a27551abc8f7f8cc7a51abb69720f9816bfa1065974ce5375bcc267fa942d44b123de1b7cc4879de1032171d39fa4abc061710db95561dd6ff63cbede9343568b0a2411be93f692def6d49d6943c26b6571d03fe90e2ba9515095ed216578b34b56c777ede426ac28a882fda74beb87c60f84ebd52e6f7b5facde13ca3386c0aa1b812ab32ccf45555ee6d2549d446e2f670874cf399ebf98d3d748ed7b89e5d8acbea2b31d26d73f29ac6a65102124d32c7602f3934cbd772a6bd35f492d0caeca6ea8a0f696086737564b8db6d27fccbf797f93383486fd254f16e05eaad979ed2af04989450b2b3bd56af1394a3f3b5e67ab70929a97b6ddba4b0ca4562dedcd00593757aaaec36514e9db600c7335ac1691d3626e04879ce1eab7b86d2b28e0eb8f7c922c7e76da4be358d9ca2660e92824016d46e7d4cb11854ed2b11ceb23c87ca5aa36db5a73dbd1a865f0eabc849b803a0dcf31d233556e2f2a30f40abbb824b36c7da6208ff49d84ab34da6271495500fc763b7e6b76f39594b048c75280641c064baeb2d66201516bddaf61c8017b0eb2f5705a1c95f74fd25ed9e9270d591458891731aca79750626ba5af2baa36d25bf0d4f55756b3d3426900154004d81d5bef2df046e80816b806ddae2f28f0f81751514ab00dcaf7fc46e2d2ff000b4f4adbf7b4b8ef6cfe9ae3216261b891c2d7427f34dd4cbf116446b303722c6fb4dc79ead30d8e4282e7a4e1a34aa036026793875c0b6b3f332e328cbda9f337f594230b92a2b1361bc2595370588bc2453fa401b09c563148418e8b48a6b55f989d16ec20eea39ed11fda53b8947311890809b098ec4f1515ad6b1b5e6c5f438b6d295f8690d4d64089a4bb5be031fad41b49babca46a61298b6d1671e9dc42aa71b4b4103ccfad8dadf69da4f2c2bd64aa8ca2d7b6dea394a747f9f29cf29a77c72da363335b315d2c48e56074fc4c4d1c6d5fc344b0f45fbeabc9fa57b46aad1bf236f4896371270999e2977187f64742100f9ebbc7e87103f8b66a6f4c10363b8bf5d2c39c8386a6c185c93eb2dddd5940225b942c4cc457bfc44855df6d85f96c399ef1a7c4d873e519a78d556d4c76fd6664dd632ba8b8c45447b32eae56b1bd87a03d6702ed2b0e7084d8196295350b89d24d38e597273499cb18b47b4afc5670886c6d2b29ac0cafcd6ab22123b46bf8fa7712452c5a55168189cab34aaf55b63617f9c26c28e5e8ac481095347f2e725149ed25de44cb47f2d7d24b53234cd716621d12ebce55e0f0b5ea203aa58f1903a47a8fbcbac9f6a40f94bf19d76a9ca72faa8ded312268c1e97de67f1dc4c94d8a922f337578adbc4b8f764d5a6e46bb33cb9dcec489595f2575427519cc27172b155bee769a6a8fae993dc41a9591e1677d6cac6f6696d9ea6870cbf885cfa8eb2bb22a2c2bb92362d2e78816fa3fdc3ed264de1ea161b16a79f3927fb528e5289d234dac4e4ef2d6a1331403702f23e2f3641cb9f94ccb063ce3b4a99bca97698d8a77361b096c729d68ab7e573f132360288e72fa8bd881dff49ac59ca74c2e3f0469574209b5edce6ef02dec0f499acff0ccd55481c8cd1e18e9417ed375c244906f301c4d40bd745b90099b8c3d60dca65b3ac2b1ae8c06c0cb0a7e8f0da950658e032d14873da49ab53452bf6130d8de296bb28079911dd3a8dcd3c423122e276797e1f3ba8ac5af7bf4ed09754dc7a6e2eb8a49e8250659c4aad5349dbb79cbccd3062aa11dc4c7603869d6b5cf206e249216d6df13875aa018a765a696f289d6b4d45cced4415139c8d3cc33d7d75588e9e92b930ec4816e72d388b09e1d4db6bc6324a7aaa6fc80facdc73a77078075657b72379e97946203a0047499ba54c1204d5e1682a203cb699c9712d30ca87501293317666f293b179f50a770eeb7ec3da3f4998a99e8ad534d243a06eccdcedd2df192cba6f1baa97a6c626a539d7de32c0f79c1e8841b4769246d523e865167861b4b7a4971b73e72930cf2f708369a952cd91a51cdf6241b1b106c7b1ed2bb8831be1d336e8267b89f3d4a78957c39f6d469aa47b8fd94f7237de59e0334a58e4d2d64a839a93cfcd4f513ac975b79adef4a9e19ced99ca9f5f84da3530d66225465b902536240b6f2563b315a6c1795f68bfe13ced1789714c94c803a4f32742493dee7f59ea999d21529936e93cb7154cabb0df6265894c42109a65ec796bea4527b491a45f948793ff84be92683bce6e8cd7185621363696990b5e90bf695fc5d4f521b293b7495196f103524b32b003bcbae937daf335c892a1d4d6b7733198bf0a839d0759eb63b6de70ceb882a573a6e553a01b5fccff494ac66b19fd66d8bc7e227fc0aabe7ccc8989cdab54f7ea311daf61f21202b0ea0c56a5f39a425de6a786688f058f5626ff0d84cb12bd8cb7c87335a77563604dc1e9f198ce5b1ac2c97b69947b22364f944ae3d345c3a9e7c888cff001241ef3afcc4e1c6bd53389368aa6b795d533da0a36d4c7b01b7cccaeafc46c6e114279fbc7ebb0f919a986559bfa631ab3894a4ba9d828f3ebe83accfe77c58f501a746e89c89fc4c3f41e5ce672bd66762ccccc7bb1b99c55b4eb8fe727ae397eb6f5028b45d3620820906fb11b1bf91e938b6eb17ecf9ceae4d6651c5eeb65ac0b8e5a85b57c4726fa46b3bc6a55a88e8d71a87911ea0ccdeb51d0fefe338b5c022d7133718bcabd530a035300f695f89c8d1efb0bcc950cfdd40179a5c8f16f506a26e3ca62e3635b950b0dc30a18922135508dae9ca25554011c569c4a422d904ca93569ab8de6278e8a204a6a2c4dd8fa0d87efca6e0013cc78bb15e2625edc92c83fda2e7eb7971f532f147784ee83d8fca7741ec67461c2672f384421042022b41ec6149845143d8c0a91cc40e08a58913a2543804e931250f633a50f63f2806a9dbc43adba44131b0e9786a1198a087b46cd1e065865d8f7a4da91caf7eaa47983ce55853d8c0dfb18d8d6d0e2824fb5b7a72bc26401b42678c6b957aa6458e3569863d819641a67f848ff257d04bf9cdb8afcf316510b2f413cb6b552cccdd5893f333d2b8907f28fa19e63d66b16695e21ef0350f78884db251627ac4c21200458aa7bc44250b154f79c67279989840276f3908439e21ef3be29ef1a85e14b67279988bc21008a0e7bc4c240e78adde70b9ef110804200c207aa64d84f092dd0493fdb92f6d42f1189a659085982ad80c478841d437e7d2d31a6f7a7a0e330cb512d7d8cf35cf30228d664b903623d089e8796232a00c664f8ee85aa23fe652bff13b7de5c6f665e3290842698388a3a9b4e845fcd1a84070aafe6fa46e108047100ea6dfb3ff0051b8407422fe69c2abf9be91b840e9f29c108405a81d769dd2bf9be91b8407342f788603a19c8402740ef39080e845fcd08d4207a7e418f35698246f2c4a0277128383ea134ff7de686f315b8accfeb94a64af4131d9de31aad1a4cdceedf61357c4ff00e11f43318b6a9402a8bba5cdbba9d8cb12aa4c2d1df18f69cf18f94d326e114cd789804200c70563e501b8473c63e512ce4c04c210805a11cf18f94ef8c7b080d4238d509ed1b804211c5aa47680dc23be39ec270d53e501b842103d3324c0f82ba659b36f184bf28e043d661b2313415c696e529ab654944865001371f097ad4da55674c45ae46c18c97c6a7af3dc5b5dd8f7663f531981309d1c8422d52fd4450a27b880d4238697988dc02108b45bf5fdeffbf8c04423828f9881a3e6203709d22d390084eaade2fc13dc406e11df07cc46d96d039084e81781c8477c13dc4207a560314b513529bc945cf5945c2a3f9225d0986cde37315a6b763b4a1cd31a2a2971cb41b7c8c9bc41475205efb4abae802151f948fa499378cfac942109d1c44210804210804210804210804210804210804210804e88fe0a986601af63da6b7018544f75403df99f9c9965a6f1c76cd61f29a8fbe9b0eedb7d21365784e7ceba7fce0e191fca1fbef2d1f9c21355ce20e6bc84a8afcbe7f684262faeb8f8cdd4a637dba9fd62740faffeb084ecf399a82df58d4210149cc7a8924531dba09d8404841dbf7bc4d741f584204784210262d31da71506db74fe908404b20b7c048d08402495416f84e4205be474816abb72a6f6f9897785fd276139e7ebafe659842130ecffd9),
('11111111C', 'Rodolfo', 'Calvo', 'Cancer', 20, 'ALUMNO', 'Panillo', 'rodolfillo@gmail.com', '1', 666666668, 0xffd8ffe000104a46494600010100000100010000ffdb0084000a0708151512181212121818181819181918181818181818181818181a19181818181c212e251c1e2b1f18182638262b2f313535351a243b403b343f2e343531010c0c0c100f101e12121e342b252b3434343434343434343434343434343434343434343434343434343434343434343434343434343434343434343434343434ffc0001108011300b703012200021101031101ffc4001b00000105010100000000000000000000000001020304050607ffc4003a10000103020403060503040104030000000100021103210412314105516106132271819132a1b1c1f042d1e114526272072482a2b2151623ffc4001801000301010000000000000000000000000001020304ffc400251101010101000300020104030100000000000102110321311241320422617113518114ffda000c03010002110311003f00ec912842e46a25128488052524a429107c292925091065944a4425d0544a6a13e82ca252211d074a25352ca01d2894d4a82e173254d4a82e1c8488402ca1084008489100a522448507c2a49485220cb2894d2531f540d5483c944ac8c676830f4e43eab011a8cc2562e23b5a1ce14e88123e2799c8d9fa94e40ec912b88676bf23b2bea079dc0616c9e856ce1bb4b49cd2e24b40d660479c9459606f4a257278aedad2698a6dcc3fb8bb237cef752603b6986a8434b8b5c7682e16ea027ca1d42555b0d8a6bc6663838730a6520f4a989550392a6a100f4a9812a127212210014928290941f02444a692a4ca4a6178d242e6bb41c7cb1e29e1e5ef3fa5a26da13306c2cb8ae27c7eb778e6bf34da6e58d16d32b6e3d4ca7336fc16c9f5eaf52a4026740bcd7b4fda375d8c71ce40023f434dcc7f96816156e3155c04557804681ce3f5bacc21c24871bf432b5cf8fdf6a2ebfe8f6bda184bc9ce74d846fe69f4b1a32c45f6e9d4aa0ecda904a6172d3f167d5f6e3723daf65c8d06cad54c51a843aa3e48d634b69658e0ff002a4a6e37813d13b983b572b990329b6f73f3d914694feb022ff84287be71fd249e5a09d02b387734b608766893b0e764b86dbe15da3ab8721b983da4ee35ff00bb7d976fc1fb574eb434f81ffda4883feaed0af2675683005b48373efb1f24f74b6f713e60ff000567ac4aa9a7bcb1e0e89d2bce7b1bc7de5c29547cff0069379e84af41a2f91f2595965e569f67534a54c94a880f052a684e09952a124a104448524a14a8856571cc686538330412ecbae5034e9360b51c6171bdb4e32c6532c065ce395a5a448fee3e83e6427f7d0ff2e71dc798e3de06963cc332b45b249363bec345cd57ad2f70fee7193a6a6c7c91869cc241009d45e2fa155710e25c77bc48dd6f9cc8cb5ab4c356098989b29595cc44a80d384199d6ff0075a2523e79f5d7d6ea3856ab091980806c49dc8d405165168bf34031b365253162418b5c7c81095948c48053082d241d4fe4a08ccee1faa3ecad60b317e527cf7f4ea6caad3639c61a3e83e6aee1d9926758d06be5252a68dd898798fda4fdb74eae73439a0cc09f7f9280b65d7075faf352d63105b3040161bc5efee984f85c41690eb820833e47f2ebd4bb35c71959b94d419c6a0c026fc9793f784d80f87f0a7512e6cbdae82220cc19dbf3a2cb59eaf3ae3dec250b9aec5f1d188a595c7c6c003bec7aae942c6fa68704a1352a20390842694728420952a66f1eaf9283ddbe5b752bc878b3dee7e77feab8ff001066001b6817a376b38835af0c2746175f40e261a4f94130bcc78862f3bc38ec201e83c969e39ed3af87330ad7365d500e44ebecabd46b66ce2473889d1481b7b9ea9cca59c9cba6cb6f88e77e1f418cb35d24c5c8e721418cc216dc5c7303deeb7f853299258f025b1cb90bdf655b8d1132d7584e9f08da0796b2a26bfbb8d2f8f99eb1695727c0488d27a724e75104d89811b5a7f02aad612e802e568532ecae6b85b723f49d2fe6aede3292d0faac6b728126226fade4aaddd9759b264c69cfaab7c37853eb3dc0030c12e3f2001fcd1741c2b0cc35052221c0e8776869d146b733f1ae3c56fdf8c4fe8f2530e220cc1ff6e9eeaa3b10eb46db7e6eb7fb4ad80c1a0ce45bfd66fd67e8b9c38a2d9cb1a9da4a78b753a9f266675c59af9661d20903cc739456a405390f20eb6e5a7b5d550e3398904c7b29981b94dc92e044473162168cd59805e09b095339c24dba7befe8557bb646fa47e79ab4fbfc3b69e66e950e9ffe33a6ff00ea9fe1f086788f2336fbaf5405727d80a5ff004dde1025e480408b34c41e6bac0b9b57baadb3390a94148952e99c84884d2620948852a79aff00c8b54f7995a7c30dcdfec27ec570cebe53e773bc68bbcff90e896d46968b6525c79926df75c23aa1823a88b7bfd56fe3fe2cf7f4fa95e45b70249d759fdbd94f85697320120936f6d7efe8a1761b4bdaf1e824fd429b87d40c71cd3a1ca75d4418fa2ad7cf431f7da7a180aa240639c2de26824738e7c94ace13887f8453741d2d175df7671845166668d05ceb610b71800d005cd7cd7aeaff00e78f3ee19c06ae1c8a8fa22a13f1308db9b5d163aebaab78f35f103bba384149bb9716cf588b4755de04e0ce60153ff25b7b5a4c49393e38de17816506776c6bdcf76be020176f0ed081f9ba9abf67dae97d48ce74824168f31baeb5f4411040299dc0ddbe5267eaa7b7bd5cfc79ce38cffeb0c7b0b4f85da83e271066c7338fbc2e7f897662b824f7609ff01f146e0735eaaf6aa789a8d6893a2acef53e2758cebf4f21ff00e1eafc3ddbc798f6f55a1c4386775458f1047c2f3c8b8cea3eabd08d7a4fb661e46ca86229b3e0304104418d3910affe6d77da27f4f9e5e3cda8e1b33e43844ea48b037bfa28eb4349683b93f5d96d71ce00694d4a3f06ed3248ea398b05cf8ace30ba73a9a9d8e3de6e6f2bd7fb024ff44c044789f1e45c574c161f63d8460e94eb949f724adb5cf7eae7c38254810a4ca8488544684a9a0a70526e77b59c23bfa79818735ae8ff002394c0f995e4949803e1df3e6350bdf1cd0755e41db1e10fa1892e0d391cecec745a63e19e76f9ad3c77df11a9fb62d1a8d7546da0071b79aeb309c12917873bc405fa13e4b92c051cd55b706f3f52bbb6566b1ad92069f4ba9f35b2c91bff004f9965b5bf4880001a2bb48cae2f17c720c32e072dff00651b3b5af6d85373bf392c678ad745f2e63d0a9b54ed6ae02876d1f201a2e00f43ef2574dc3b8cb6a68213b2e7ea659af8da80a3a9500d4a6b5f2a8f146f875ea974e4f6c3e37dae65371653697b848e9216053ad8dc53a63234ee6cd8f5d56d0c253692fca3cf537bda553c5f686952397217189d80898f89c40d760af3aefacc2d639ef57916b0fc0de0789e0f5b9f629b5b8496f883dc48bf21ebbaa4de3cc78ce1ae6098cd169e44b4c72d56de0f1a2a53d41e696aea7d5664b3fb6ab119843af22ebcf78f60c52ac72fc26e3a4af49a94a2eb8bed6519aac1fdc00f9c7dd5786f35c65fd44ee7af49e055994f0b458f780fc8cb1b1b8e4b642e39f4258da6d2672ddf3725a39fa2e9b863c9a4c9d623d94cd76a7c9e2fc732ae84268294154c8a842100d095225400a9716c08af45f48c788100913079abc98f700093a01280f1ac3f0f761f1c28d520b803046864588f45bcfc287d46877c236e6554ed755cf89a78a6b0b5a1cd6b8ceb06c7a5a56bd01e2908f25ef34dfc59b25cd5d1429d26e62d1d05e49f559f8ce3b49861f727463049f53b2838f625e406b675d6263afb2870fc3b0efa3ddd4ce5d9b307b478a4d8e69d76538e5f7a6da967f18bbc3b88b3105c1941e32804e84c1d0d8dd4d59e6980f61969dfec7aa7708c0370cc73696605d198cc38c682468374ec788a65a1b776a6f7eb753b93be958ec9edd070ac567602a0e32f31655f823a1a02b98f64d8eea79e8f9cd32df441a6d98dc91793cac154e2381a5896b45468058201600d31c88b885ab86a00db7575940685a1566d9f0b7cbeac73bfd30652ee69536e5d64f8892773f9b2b1c2b83e4133737b5afbae859871b0f9279a709eadbf4a593d466e229437c9713da567ff00a5177f9b47fe40fd97758c301729c4e8e7a94ad21b51ae3e4d04fd80f54b179aea373b38e85af0ea6d2cb96b4f49b2d8e1ed8a6d1d16361aa097060f0cc4ed7b405badb084f33dd4f9ef24ca694a0a8c14a0ab73249426ca4403825489c100426b9b220ee9c8280f3ee39c241a5569375065a3d6428f806203a9b1dfe201f3163f45d571bc149151bb59de5b15c761a89a355ecfd2e39d9caff10f4307d567fab9ff00d75cbde6a7faae93fa569bc04ea78268d93b04f90b4a9b14cad551b479055b89d0864adb6b167f1464b4a76fa297db3f85bfc602dbe214ed65cd609e73831baea2b373531e49cbe8f53dc66d1743d6b30485895a9b838386daf50b670cf05a08dd285a89da146f29e5cab621e9da891471d710b0d94c3aa35a45af3e4b5f12fd565e08175611d75f294a2af24f6d5ab8782c0d882e04b46816a82a06538b9b9e7fb2942bcce39bc9a9abe8f053815184e055323e509b29501384a88420042108063d80820e86c571988c0cd4734b4cb2608363cade4bb6597c5b045c0be990d745c99d39db929d4efb8d7c5afc6f2fcac1e1f5a355bf877cae58f82a45c0306fd403f75af84aba2cbf6eafb1b99967e3c1d14a2ad92b9e08ba768938c0a788a6c7303dc013785d29c5b0326c442c1c6e1d99ed37da5494b0ecd0b09e424c7b2acff81ab3f689fc46a3892c634327571327c9a02d7e161c180bbcd537d38122dd214f47196b84acbd2fca58d07b956ac542ec55fcf64da952c8a27bf8ab8a3655386b08aecffbbff52ac3ae6118503fa868e4d71f947dd19fa9dff1ada4212ad5ca50942409421272108405942548801084200414210187c738737baccc68190c9f276bf6f658b86ab061768f602082241104742b8fc7e17b9a994cc1bb4f36fee167acfedd1e1dfeab41d57c32a16e21ce1616e6a3a2f0e696a7b293b296b0807a890a73e9b6bb4e661af99eef32b429b18e1e1703ea172b89a95cbf2d42d006900907aeaa7c360ea933de0e960ae7559f0f676ba1af89a6c6c38c9e435f5550713a3ce3cc7dd673b864dea54277201fd9369f0da6e3018207ea22f28ff7557c5991a2dc531f390cc6a40b2563bc2a4c8d6b435b602c21567bb929b7acf92073c344a938234b9cfaa74f81bd62ee3f41e856762ea4c30189b7ceeba5c3d20c60634400202acc63e5d7e92a0212856c425091284039084212b48404a80448950804421080166768688750748bb4820f22b4d64768316d6d3eee7c4fdb90e696be2b13ba8e730f50b75d42d1c3d4dd53750cc2daec7ec53b03520e5758ac1db7d2f54a61da89552a3c305b31e917f9ad4a201d559349b17129e7a7f9dcfcae7a962dce31ddba3d169d1a6e23e18e8adb30cc06442b26a3400aac4df25bf59afa242a58c7868f457f138b0d9dc7458ae26a3b311e11a754488b7aae67e33a98f40bafa665a0f30172f8865974982334d87fc42aca3cb3d44e94210ad884e0913900a8421095909522100a9109ae781a9402c2142eaa4fc36eab29acaaf273d43ac40b04b5ae2b38fc9731dc498cb37c4fe436f32b917bdef7f78fbb9c4fec005d0bb0800d1667730e8dc12b0d6adaebc63399e92516593311869be879ad3c3d210ac3b080a721db3f6e7998c7b086bfadfe8b46963046b72a5afc3da751215377096ed3e5255278b27150390d953c47131300c9e42e9f4f86b4fc43ca4923e695f826b4e56c0f20abd26f59751ef79f15872dfd55ec2d339614a3090aeb2886b5169c9c65e2792bfc1713e1eedda8bb7a8549e2494ca0c27c4dd5b11e6a65e53dcfcb3c74c9557a3589682e1a856415ab92c108095010454254202705239e028ee7547769f0f85ce4a664dd48042584cf86654c220cfba91290959d826b955eab42cbc4d302a076ceb7aecb4dec2d3d3e9fc28ea510e11b1586b2e9c6a23a2d8569aabd3041caef43cff9561a138287b242ae590ae3544f6a7c2eab3a9ee2c98da3b9bab6a37bba25c3eaab9be24dc5be02b34d9264aad8864b9312a861d9724a930502dfa9ce803cff00656693000549c330f27bd222c433c8eaef544cf696b5c8b859b7248641b29dad48f6dd6ce72072742686a700970ac28422508e126212c2584a026a30b52c27c232a075196a2213f2a32a0a990a0752832df6d959c8912b3a26ac40581de1363f9a246348f0bbd0f3533980a63d87499f3fdd4dcb49be9ed625731454de41870f22ac872986acf6260a6ad58a7401baae0fc95fbbb2a8ca7f138abf51d681fc2859463533f4f647e25f9719cec2971cc6ccb0037712753c82d4ca9b965dfebf53fc298aacce235ab51909ae0a5ca90b551446d09e1a9431383521d372213e10824995109cf091302110842408884b088402242d4e4898465a9214b290b42023225340d8eaa5ca98f64f98d14d9fb394d84b952b4a584e0b4d0d48f76513ec399d949098c12736dfa7f7451053640eba9f34e4e284c8d84425420102700913820108427210121488410821084a8419a84b0884010912a0840361109d092100d427426b9206bc5e46bbf5095a644a73554c6d62d73003f1bb29b1302351c92be8e7bf495de231b0d7af452c218c00404e01390ad340425844260d8442724840225084a100e0108084110ea9cd4213010842010a10840012a1090224421380894a542010accc636499fc83fca10a37f159fab7843e0f71ed2a74213cff00185afb404a5084e8204850840204a12213248842120fffd9);
INSERT INTO `usuario` (`dni`, `nombre`, `apellido1`, `apellido2`, `Edad`, `rol`, `localidad`, `correo`, `contraseña`, `Telefono`, `imagen`) VALUES
('11111111D', 'Luisa', 'Badia', 'Sierra', 32, 'ADMIN', 'Fonz', 'luisabadia@gmail.com', '1', 666666665, 0xffd8ffe000104a46494600010100000100010000ffdb00840009060710101215121112161515171718171617151715181818171818181818171718181d2820181d251b161721312125292b2e2e2e171f3338332d37282d2e2b010a0a0a0e0d0e1a10101a2d251f252f2d2f2d2d2f2d2d2d2d2d2f2d2d2d2d2d2e2d2d2d2d2d2d2d2d2d2b2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2dffc0001108011300b703012200021101031101ffc4001c0000010403010000000000000000000000060002040501030708ffc4003d100002010204040403050703040300000001020300110405122106314151132261713281911442a1b1c107235262d1e1f03372821524639216a2f1ffc400190100030101010000000000000000000000000102030405ffc4002d11000202010401030205050100000000000001021121031231415122327181c16191e1f0f1132342a1b104ffda000c03010002110311003f00eab4ab34ab22cd6dceb6c75adf9d6d8e80322b159158a042adafcc56bad8fcc5004071b9f7a61ad92733ef4c352518154d9a7fa87e5f91ab9154d9b7fa87fe3fad2023623e35f955fe1fa550627e35f6157d86e42840c9988f84fbd4315367f84fb8a874d8918ac1acd62818c6a61a7b56b34018ac53ab1486348a559a5401754ab34aac835bf3ad91d31f9d6c8e8199158a78a6d02153dfa5369f274a604097e23ef4c35b26f88fbd30d48cc0aa6cdffd4f92feb5722a9b39ff00507b2fe6690c8b8af897d855ee14ec2a8b1bf12fb0abcc1f2149013e6f84fcaa1d4c9be13f2a874d8918a469560d0318d4ca7b530d203158acd628198a559ac5005dd66952ab2063f3ad91f3ad6fceb647ce801e29b4f14d14c0429d274ac53a4e4280204df11a61ad938f31a65aa0634553e77f18f61f9d5c17506c48bf6b8aa9cf17cc3d87e748642c6f35f6abbc0fc22a931c3e1f6ab9c07c2284059cbf09f9541a9d2fc07e55069b12156291ac5218d6ad669ed4ca062ac566950062952a5401794a952ab2063d3e3e74d7a7c7400fac5a9d50f30cc63810bb9b28fcfb0ee69812c0ac62a5545d4e42a8dc93cab9d671fb5030dfc3817d35b1bfcc28f43b5e84b8b78971d8e608ebe122dbc887cbb8bdf575da8b1ed0bf897f686b1b15c2c6243fc6eda13e57e7417ffcab33b972e003fc2cac05efc810474a1f58820d4eaa4126e4fa1b1e7bdf7a6e118ab902fa2d71727d36bfce950cb19f36c4b31669a424eede6bdba8baf2f9559cbc558c2be790332ec2e2c6c3d4509625f4b8b9e60d8fe35a9f16d65bf63f85ff00cf9d3a1585d84e3760478a188ed7dc7ceba770ce75062a30626048e6b71a87b8e95e7af1ae7dbfcfeb5b72fcca586412c2c51c1b823d3bf71e9ca8da2dc7a8dfe13502a070cf12478bc32b9650e546b1c80603cc05fd6a7543290a91ac1ac1348661ab5d3da99400a952a5400a952a54017b4a952ab2063d3e3a6bd3e3a007486d5cd3f691c4310b44af7b29f84efa891bfd01defd68878fb399208f445f1b75fe11dedd4d700cee7959d99d8b1bee4f334b9745254ac7637101d9bd7d7f2a79cc5d8824923ad4081750befb74e74599270e195548d5e6dd411d3fa536d2e4229cb828ce2199581bdf98f7e47f0a9186d80d4bd0eddf61b7b6d5d2f25e07f0cdd802bd41156998f0a61ca9d2a07f5ac9eb2365a2ce2f988d5a476bdfe7fdaabe63ccfc80ff003daba6e27838ef6aa3c6f0a32026d7ab5a9162968480417bd6f1205a918ec13213b7e955d239f6ad39306a82fe0ccfd206649365604ab002eac371bf3b1e46ddebb8e5d8812448e39100d798617df735d63f661c4c05b0b236c7e024f5fe1f9dff000a9921c4e96d4dbd2358acca135329cd5aef400e159a68a75002a54a95302f8d60566956840d7aca9b561ea1e678c11a12376b6c07e1ed52dd0d2b00b8db1a0ce77e9a47cb9fe3b7d6b93f133de56239103f2146b9e4cd27998f36207e64fd493f3a06cc3cd20bf2b7e1fe7e551a7cd9b6a2f4d1132a01a45537209171dfd2bd15c3796a448a48f3103b7d0570ae1fc2a9c5466d60181f4af43e14794546bbca45e846a2d9266936e56aaf9dae0d4c946d50243593368a204cd615479835c1a219d36aa2c7477dad528d90179b6115f98de82b35c01437e95d1f32834f3a15cd22d40d75424726b41304952fcaa4616678c820dadb8236371c88b75a8cdb122a44788239806b738d1d538378e3112010cd67626c1cecdbf70059b973a37c04f29919642082ba92c37e7620efbf4fad70acab18aac1b49bf4b1f95756e1cce92675d2d7b21043731ba9b72b8e5eb58c91aae02e734ca45ae2f4da910f069c2b58a78a603a952ac5005fd2a54ab5208f8d93481dc9b0ff003e554b9f9223b0f9ff007fcfe557398c64a797982187a906f6a1fe26c4a987503f74fd2db9fa03594cd34ce6f9d4c0aedc82edea4ec3f0fca82e7f88fb0a27cd492141dafbefd3dfe56fa9a1b917727fda2881acc97c24c4e21413ebbfbf3aee4df6a640d1c8910b5d55a32e6dd0b1d42d7edd2b8df06c40e25588e7d3ebb5746e29c2637152058dc430002efccb13cc69ea2deb6dfad67a9ef35d25e8226619e66b13e9230f28bfdc2413f53b55d60a7927452c850f51706df31cc5739c6642d8793cb89b9dbebdf737ae91c1b1baa5dd8b7bae9fa0b9daa6691a42d2ca206799c08548b5d8725ee7d68465931939bcd3a409fc239dbd86e7eb4b8d9cb62fcbcb634a1cb44b6d714cf7b7516f9587e3bd54524ac53b6e915b2458226cafe2377626ff008d41992c4806e3a5f9fb5fad58661c21a08648d900eba813f81a8b3618af337ad135d33369f6a80fcce3d2f4d48f6b8a959fa7981ad3873b56cb838e4bd544ac9d3ce2fc81b9f4deba366182d017130fc405dadd40b731dedfaf6ae7d8470ac6dd4574fc8657921175dfd4ec45ac36fc2a2454424c931a25895af7b8beddbfcfcaac01a14e179b4ea8af7f0e46507f9492cbf87e544faab31b370a78ad2ad5b01a621f4a90358a0020acd2ac3301b936ad5906bc4bd873b7a9a00e26cc51c954ff004fab720d6372077dedbfad16e2478b72c7c82e6dd081dfbfb573de2e72afa6dd2e7e7fdd6b09bb37d25408e65316b93d7f5fed7fad54358ee77fbc7fcff39d4dcc9f9fa2dfe7bd564d2587b8fd3fb1ab487265ef0049af1d103c8eab0e9cafb7d2bbaf86a798e95e7be05c45b31c376d657eaac3f3aeff00889348358eaaa91b68bb89533e0a2f12fa145b99b0bfd6ae30c148baf2b50662e692797421f2dfcc47e5452b1c88800b69d36ec41fd6b33a66bf139c71bae89ee399b55df08e63e2c56ea3623b1aa0e2f59db122c834802e5bafe3b546cada481b503637bedcbdbdab5ab88b8905b9d9da817303b9a3497169894b8d9c0dd4fe63b8a10cce2b134b4c357da05e7572454156e956b8a6512306602c391aaeb066240daba91e64d66c99856375b0b926c077bd1ef0be6522268d1ab49dc02030dfb1e75cfe26b3afa6f46b8416092afdebfd2fb5ff000ff054b045ee501d1a49194aeb6bd88df99b11f5a2787117aa4c1e20db49f6a9703d4328ba47adcad55d04b5311a9099254d2ad61a953104f5a31c7cb6ee40fa9adf50739c3c924768982b060c09171b73dbdab47c10b935623485d1e876f975fcbe55ceb8c250f2dd4dc69173ea2ffd68b268defa753339df6206c798d80dff002bf4daa8b32cbd1412e428d881d2d73df9ef615cf2674c11cef31c3375fbc081f9feb54d994764523d47e346cf16b903c9c80f203cac395e86f34c3590fb035a458a5129b87311e162b0ee76d33444fb6b17fc2bd11c401bc2729cf4d79b3130fe35df7817881730c1ab311e2a011cc3f980b6af661bfd474a9d75c32bff0034b6ba07b2be2fc3e1a355789cbdec6c05ae4fc4493d68e8c98991411185bdb6241e66dbd50e078570f289a29e30c0b923d8f623fcdaae60824c3a0512b90bb0d576240371737dfb5c8f7acb0f83addde281ce21ca71ac4b01180182ed604dedbf2e5bd06e78989c3eecc9ccf31d8817ff00ed4719f63312ca4090ef6242af3b0b1df6b6f63f2a01c5e5accdaa524ef7f31d46fcafbfb7e15a405353ac963c0f8c96690192d6b74047e7e959ce2d76f7adbc3f2089893b581b7e554f9fe62110b1ebcbd4f6a2ae782652a8640acd9af2b1f614fc1adea1172492799356186161f8ff004fc05747479cb32b34196ec7de89b25cc2f178679a91a7d89de85a2b5cdea7e55210c3fce468608e9f823e5049dff4ab085ea872ec56a507fcf6ab58a4acd965bc4d53237aab85ea744d4809cad4ab52352a0418d66b14ab53329f3d8744723a795d8017e9b90a6e3d0127e54359c603442d24ac6461651a8580b9df4a8d80e63a9a38c661d65464717522c683b8b342409acb331be8417258aa9f311dba9ed594e26da72037369030279960145bb753dbd2a973180e9bf7bfe40514c38291d012a14ecee58927b2c7a547977b923d7d2a8f3a8d9750241ea6dc874dbf0a846ec0bc6c3b7b1ff3f5acf0f67f365d389a2dc72743ca44eaa7b1ea0f43f306cf1305d49b721f8f3aa0c6c3d6b654f0cc249aca3d17c339ee1b1f109a06b83b329d991baab0e87f3e62aca68c915e61c8b369f0728970ee51c76e4c3f8587261e95dff22e2b5c4c6a5d743db7b6ea7d47f7ae79e9ec3a34b577fc9331585b83b508667978bdc9f5a28c6e6d18d8b004f2bf5f4142bc48eea85ed7152b93a13c641bc7e282b1b6c28373cc4b4920bf21c87eb57388959f73fdaa831e3735d515470eb4ad0dfb35aa543ccfcbf2add1b6a894f51b1ad6479bdff5ff00f2999d10e78f49add836b1bd6cc525c7a8ff003fcf6ace562cfd3e7eb4c5590af28c4a90ba4f31f88dbfa7e3441879683f2b8ad39d22c2c6f7e573da89f0ee6a58cbec3355844d54f857ab485aa18c9a8695323358a041d52a558ad4cc47950ee61860e0bfde4423ff005e63f3fa8a2235064015cea1b30faf2bfe9f5353356545d1492ca1269d48b5d94822dbdd14edf53f5ae7bc4ea6597586ba5ec0db63dba72bff005a32cdd480c2e431511837df5472108d7f546068678b1d151557901e51b6dc8b1207ad8563d9d11e01948fca77dcb11f402def7aa5ccb0d6f63caad71b3d8ee76ebed60397caa362b75b1ebf8fafbf7ad1604f20994b122bad7043de153e82b9bae135ca17f8b6a3ae0fc4187f71282aebd0f6e868d6cc4343130af3055674b8e42b4e7316b88afa5631f30054deb7c2c1d08ae556763a39be260b03e9548d852fadfa20fab1e43f027e54599f2847d1703530504f2049b6f5af38cba38834310234a82d211f1b1bef7eb6edd2e2bb22ce0d5696016cb94f997d3f2bd2b6ab8ea371f5a9397a5b73503c5d2c58743f5b53ec9e1130d98036ded7fedf9d42bd9b6a9afb136e5ab6f62350fd6a0bb6fb75da840c21c9f16b6218ee4def44701a034520d8f5ab9c0631e0708dba936f6a1806b856ab681aa9b0c6f5670354302ce334ab5c4695200fe952ac56e6466aa31f9a6104d1e164957c673748efe6d813736f86e2fcf9d4cc666314570ee0594bb5c81a5396a27a0bed5cbb8332dcb7158fc44ca647d0eaf0877637b11fbdd44ea6f30b598f223bec9f04eecd21b9a66ac59cb3ac11788da1097691b48b02c3a0f28dafd687a4c4075d6cd724e93ba922dbf2e76f535d338dfc09305e34b059ee0206d22417617008bdb617b5720ccb18f2b9b288e32c34a28d828d8313d4fad64a26f1d4cd1ab10e5e4b1d83a903e9b7d48ad11b9b58fa5bd3b7f9e958cd74860cb2061e9b693e95b2301c5c6d7dcffbbb7b73b7bd55157916023be2223cbfad745e23cbcb61229440f34e80297845980eac57a8e7b58efdb98e7984c2c92b30894b3281f0f31bdee3bf2ae9bfb39c44ef8122320c91cacb6975756572a6db8f2b103b6dd29b5d98ca79a02e6cca400126e01b124152a7a2ba9dd1bd0f3b6c4d5861b3b0a8589d945cfa5cd87d4ed441fb5bcdbeccb872aa43eb24b140c8c963aa36279efa4e9f98dc549ceb879f178229842b15c0b820046d366010ff0009ee4f6db7a970582d6bcb3e4a05cb30988c3c78c94b6a6606ecd65465934855036376502e6e4df6b50f71bcf2ab841b211cc7327a8f41b8abae0465386970f3599a19199a1d372a1581d6bd1c0704edcb6ee2e3d9b675f68948d1a500608ac3cc188e6dd8f4b55a54cc5cef9e595b18b20b6e4fe42ab3c3373b5b7a94be6016cd6e571e9d3eb5be4501404173dcff004a0df92239b6ddb73f4b0a8dd88ad9d581e76fd6b544a2e0eab1b8dac771ee284896cde39def6357f0e256578eec06fb922de6b6c2fcad7ebb74ad587cb12689d9bc9a6f663d80bdcf714ec3e431b613ed226b7c20937d2096b30b5af7dff0a0994a9602ac1bee7b55bc0d4298acd1619922b36d68dee010db0d13211d185891ebef57d04beb52d151929705ec069569c2c97a55051d229934a114b31b01f99d80fa9029f555c4f864970ed1b1dd8af863569d5203a900efe600dbd2b73093a4d959c45944588749243aa16d692af24d09148c1d88dcd9d47a72a16fd99659828a0931aaed2329985c06bac4392941f131550dcbef0ad396cf8939afd8b146f1ac5261804d5e18124464527f999475ec7b55b641c383275f11a7bebda5bd847ab55948bf23d3d6fed4a58465a79cd7f249e2ecb626314924cc9ade38d0313a3ccdbd97a1dee4ff0028a0dce32cc3c18e921958c0852f01620a9279824f4b9344fc5993e2b1732306568d98246003fbb1a41677ee490df255ef5659bf0dfdab0ab0e23c3967443a2422c35d880c46e6dcae3ad2ac2c8f4e4ffa92c57e3e4e1b9ac6b1b3002e6fb106e00df977bed51d65654058ec49b58efb6d6f4a3cc3fecdb13209924755113158c91f1d9755c6fe55dd79f73da9b87fd9f4711c2c989c42912c8a3401b35d19c22b03bdc802fb73f6aac1a39e7048e00c8a574125f402f77b8075c65480abd46e6f7a9fc4d9e4f87c4b261f545e4d2e4a0019ba4897d98d8a80de963ca8a32448609170a8a574c6194598ae8be91e63ccdfa56acec9c401859238da4d45dadbe8883378645f7577000f4f354c5e6d91aa9ca349d302b8eb3a83178a8c5bc5580101092236beccc4a9bee40b7a2fad69cdf89e15c3a261564c2ca2e1cc4cde185e91efcee3cdb72b7bd12f1161b0d1604cad870ad2a29d07cae1f48d0a586fe537fc6b5f12f1061465c8d1c71b3314091b0042347663a87f2816f5d43bd5ae160ca4def79e81ac9a28e19b091eeb3dd9cb29b10593ca1ff8b56c6df5e75b7883288e1c4bcceb642faafbf94e95276ec59bf4e95af2ce1a69a75649cada38e7d7b33877dc0b7bab7c80a2ce27c34d2a3b61993558ab0650e0e90c7481c83ead3bf4b54cb0f0cd34eddb68e4d8cc25da5d076466dbd01dc9b6dcf6aae676e573fa510c5c3f8a5c378ee3f76de7b1beb1736d44763cfe950f35c871507865e223c4215391bb1008161c8efc8f6355452d42ae7274dcf3fef4fc1e0da46503b8b9ff003e7f4a2e5e0499e247605182b6b8c804b3293f0106de6b0e7deaa725c2e222c405f01d997778ede60a6dbfd08a4b3c0e534b9080e42f8980c5148174ecc39decb70a7b5ce9aa6c0f0e62bec6f21902c60990c47a95f2defded7dbda8e734c04d1c322e0a31e2c972c6e05bcb62dead65007a91417c3984c6698a07b886493c4d279feeee4dc1dc02403ef634a2d93a893c19e0dcb1f132ff00dc34aa56356818df7b1d8a93f101b6deb57986c66a9245234b235997b1f4f4bdede95238d30cf265cb234663923756d37048dca1b15e9e6bd52e4d1784a9e216324a35b16e7f786937df609d697392e3e97482fc13de9542c0c9634ab366e75da07e38c7cb879e3c4985e4870e41db906656defd3981abe5d68e0500cbc510e65885cb9632d1b8633b12ca6cb770a839db65bb763b77add1c9aa93a5658705e7cf8bc2b625a20d219c8658c01ccaaa9b9e7a6361b9decb56926099a69918eb8a540f66df4482c9603a2b2a836eea7bd6707858618a74c0ac71b2937f2b6812845dc81cc05d37b76ef7a0ec7e67991c34ad878dfc779e340da77319526e2fc85d6de818f2e753564ca7b5a4cafe24c6e61063211a2ea921302a5ceb201075fa95245b90068df118a4588e396191a43080b1d9b59b9d4a853a1d4db9e9427c5b9c6213170cbe1b8118de2009d5a97f7845be2b6f63fcbef44f1e6ab0abe2269408022b28d36239926fcd8b5d4016e9eb43c50b4e4a4e4d3ece7bc319be6120c65d19d2524ccfc844ff007b63fc9e5b74b0a767f91e61883828ad68bfd38181375d83977b7c3651b7a47573c3dc6b1cb062d422452bbbbc6a00f30976d4dfc4cbd7bed5078a78ee457c2ac07cd0d9e51c83b91a346dd0a96ffdc7515ae7a473bdbbf32eb8fa8669062861edaa3fb57876d5be8f12dcf95ed7de86321c871a98d79de4dd5f4ca5813e3295bf97b586823b7ca895719872bff51d4e13c0bf336d1f1fc1fc57daf433c3fc4c7ed4e65d5a710e3b908fb469ec2c154fadaa229d3a35d59c54e16dfefc971c5bc3631ac9278ba742b2a2eda759bdd98fc80f4de85c704412e08623c6b398d9c3eabc6399b1b7602c4ff4abde2f126170cb0e123660eefaada98a6b624b5fa799ed6fe6f4a14cba1cc66c23c3868c980b79afb7c3762a97e772b62075b0eb551bdbc91a8e2b51632d10f81f152262fc9aa64368dd803b2f24620f202df4bd13719e38e070ccb878c86999cb328364d44191c9e8496007bfa555fecaf1815e5c3b8b331d6b71626c002bf2e7f5a25e21c78c260e438a2b2b3191156d60fa8b68523d16d73e9533f71b69fb39fd004c3f1648700b85b307074f89ff00881ba807bdc15f65a93c41c78cff0067f056c632b24b71b17171a05fa5ae6ffcc3b55acd9a60df2a8bf762f754f0c1b10c846b20f31b126e7f8fd6b6f19e3f2b46c1de2571a9643e1d8698b4e91ac01e6dd57cbd90fcde3c109bb7eae904784c4aceb162a397f71e1b965b0b1bdb763cc142ac3eb41d83e2b57c7bbaa1685d5630556ee0293693617b12c6e3b5bb574381493198445f676566247325882a500d8837727e543196e7b835cca5d2a8a1d1634900e6e97d5e8037945c73d03bd4452ce0d751b4e39ec7f18620e5f859648f5b492b58124b042cb624745015490395eb9ba711ccbe1189ca948c29b806edb6abdf983615d0b88f89618c4e98878d81da2896e5ca945b87ed76d5bf622a972a7c3b7d9bf762fe1205f2ead2587de3d2e108b9a22e95b454d39613a2f728c7e224c1f8d228958a96558c58b2f620edab9fa501e5ecf2cef2484e985dc27fca43753edabf1ab3c767589c1e2a586165d1a8058dc5d1758076b6ea2e790ef43cd24b34ccb100a2f2036d94ee19cdfaeeb7f98a6a35912d44f1e035c39de9532034ab33a91d8b13ab4368b6ad274df95edb5fd282f2eccf2c9b170cc18262443655b80349d43c33d0b0bf2e7603a519632748d0b39b28b027fdc42feb5cef88383b2cf130875787e24ba585c932e95dc7f29d4805ff009cf522b4c1cd2bdc5bf13f1062617d3e198a1d42f2f3d6bb13cb64bee2c77abd7c632dc85d49f116d40581651cbaf9496ff8d47ce328c3e2a35c2b33de350cbe66bfc2d1a9627e3dee6c7a8155b0e23c0c1c52b4eccaba0b32287baab8d48069b9161a4f5b0a4ea884a4a6ede1ff00a2cb19288e780c814871246ac479958e82a2fd8d987cc5576698743e30c5a4670ea559756fb05bb17076166bdadd2ad335c161f14d02483cc43385b9be801758b836f88a6ff4aaee27cae2cce078c4aca164704aec35c7a974bdc6ea1ac7fe228ae071bb97efa06f85b2ccb465f362101908328d440f156c7f768a2fb12a10faea3deacb89717974188c00745b86d618580442ba11dff8bcc10efcb413d287784f84b12b85f1bc6043d9cc2a6ea77011b55ec4e927ea2a5e7ffb3f77c5400ce5924d424d440645400e98c1e62c6de9ceb4c7939fd5bb11e96439bc9e368f0d7c231df55c7c77b68d3db4ef7aa1c8b32c3498bc5246a031652ad7beb0a0072074b3dcfadef568b841e07d8fed0de2783a75dc78ba6da3c4faf5a14ca384b4e264b4c57c19134142ba8f27b38e9743a7d6e6a6354ecd355cb74695fd8bfc7e6fe046c714163bcacb1d8dc32a8664bf66201dbbfbd566078ea24c299261a5d752ac6a41d6d704002de5beadcf2d89abaccb2dc2e39344969163905c06e5228e4d6f46e5eb555c3b95e5eed8840a2411cb6fde2821542ec56fcc79986aeb6a6b6d645373de92aa06f80a25c548f8a9bcf2aca48373e5b863603b79cedfd2ae78a32dc3e3f04714c4a688d9a367d4a16e41f32f72574ffcb6e9549c03853f6a964c293f66d4518487cc46e5196c3a7979ff0011ab9fda5613152e1ff74078318324a01f31208005ba80096f97a0a1fbca8bfedf057e338370587c2452f8e417308320f3236b3b955e82cd7bf64f7adbc47c2596452e1175787e24ba58162de22e9bf327cbe60ab7ff00c9ed5418bc9f324c1c3e279a21631a0b964f17a116f6f6d56a6e7dc259934b8712bebd5a62465248882ee3576db51bff0029f4aa7f2651adcfd3e0e8c6582051838d1950c723003569085acc3574377d876a10e15caf0b33621f0d6d68488c3efa005b2b0ea4137de8b24c9f113617c27942cc630a5c0245f6d440d8effad0c65fc3e980966d7379e30ad1e86d2595b5025d7f87ca411fdab25c3c9d13bdd1a5fa1578f5c334ff00f7c17c912b5b535b531b3016ddb7516ad7c32ed1620c50461a29944aa598875855b48737e7cefa79d42e26cad659629449bc8b76bef65000040edbfd4d4ec8754b159895f04946990152625b59148f330245edeb4ffc479dc5af156361671878a24f12665592665160546c413cdc03cfa509cf9c46b0c6986058de55239b6e0a83f3beaf9512e071071692955d117fa58724798120f8926fd6d6dfa5e8760185c241048b6772d26a717e6030e5d812a3f1a1781bf28bbc013a56fcf48bfd29569ca652d1a33732aa4fd29543e4dd3c1db31f0c6f1ba4a018d948707969b79bf0ae75c61c15248911c34e5bc264508c6e504ba754baaf71bd9bd81ed5d2a48c302adc8820fb11635cf070a62c298a1c4ebd70b47e2b83fe95acb1b0077215858fceb5472eb758b0b445895c3682e8711e1901ec7417b58311ced7b1a18e14ca719049261e4656854df7bee58121a3edb81707bf71bd970d2625a35fb5c769e02f0896f7f116e06aefb85526fcf63ed4e9163b0b8ef1e596331cefe1b7301546a30800fdeb6db7526a176826adc659fe7c96b97e109c73699bcc916a4426eab69343ec3a1b904742a39540fda7e2b10d833f6500c2757da2453b80182940399049249eca7bd4f19444718192f1b3c332be852030919496d405b56b00db9ee69f9a06c2653389880da24034aebde4b84041163b917bed4e3d0a569b496336c03ca3118d5c147879226584b864737bb8275a20ebb3027e9db7d3c4f9be6126610b784e92c7610476f8ac4876b750e55afe9f5a28ff00e6c932e10a01cd5e71a6fa74dd4a2f637f303daddeb19871961ce6b1269468d15a1f1b9d9e42bba9fe1054293fccdd2b5cf839d539ba9f8087118902138c5c3932f82084b7ef2d6d4223d7e23ca81f85b178b4c5c8e62772eeab88039a966d218ffb493f2bf415d09bc4595dddd442116c2de656058bb31eda74fd0fcc6b86f89125c54ea42aacac0c46d6274a85b31ea4dae3e62a23c3c1a6b56f85cabee4ce28ca67911060c88dbc6f12423cb70c85189ee4823e9e943580e15c5ca658c49e00522376b13ad4db50163cb4eff31f223cdf3c6cbd59e7632a49310961631a942517f9bcc845ff009bd2a16478bc54304f984c4489283378209d4a00d2a549d80b0008e76b1e7b5545ba27561194e2dde0a0e0395f078b97053ad99988522e46b00ed71d085247b55cf18e6072ec188612ecee1915daec553ef3337701801ee3b544fd97e3c3c98a5948f1da4f11afccf306dec49f6d54558ac578786964c6aa695f12eabb868f5108bbf565d22ddcd4cbdc6b0f67202af1bb4f81588965c40650ce36baa104383dc90a08f7ef5a38af8da69130fe0868da360f2300429717080775203920fb74ab9e14ce304f97cb1b44abe12b6b8c9bea0c495209dcddac3d081e95af17c4185194346e89e20558bc23b8f10dc89075b7c4f7ee0d552f06572ddeee504fc3f8e18a8a3c54d03452a2900b5c0b3aab1643d518693bf2b5ba573b59f1389ccdd9e33e60415e6162e4a7d46c3ea68c324cd8e6b875292089d193c55517165604800fdd75040edf2aade24ce061f1912e134ea8d0f8f7b10558a90ac79dc5ae3b6aacd72d1d0f2930578c328c547399348f0dd444bbf21a6e6e3a6e09ab04cc06070fbb172d611adbca0aa817b8e9d77aaccd3339279c867e6e4b0b9f290028b03fcba6b18dcc6288450d8cc55d59cb5c9db928f5deff004a12ba4537b537611a61a79b04a22012468c2f9b6b6a3791f61f11dcfce8672fc8a38238659db7676ba1b15160fb7bf94517e6be2081e6c2abbc92a22a0b9f2837b3053b020313ef6a04cb32a9648a2f1ded09792ca4d9ae0317e7dca7e7447b1cd70b92fb299c491a30160546ddac2dfa52a59514f0d347c3a16df4eb4aa59aae0eec7d7950ae361c561e513e1d41c3b2c65a2375656174d2074054adfb1514562b9ebe698ac0cf89389133a3e21344a7e0f057711c6392fde07bdbd6f57473ebb4a36ff322f046678c189c4e131f139f118b3120b2a33a93a49170119176e9e5b75a99c6f936231860861016042ba9d9b7160403bee74a826fd6e2a2e57c78f3e62f8730308e570b1908c2450a2c1a40772a773fcb7a958f9219314306ced684f8c9adc9692466624dfaaa82542f627d293b4ec549c76d9a21cdf19f6b8200e0c71c4faa4b6912b95648af7e46e54dbbfca8831998c71e5ef34cdfb9fb3aa0503cdaecf1b004f32c4a81db49aaad0124844e400f3deebb009193247a89f54407d4d6de32cbff00ea1975d03068944caa2c15980657420f5167f62477a239134d3fa7031b86b2f0f82119081c5c2ef79d5620d72475b28b9eba8f5aa89ff67d8238ff00083da2fb397316b3e26abf87aae7eeefabdc76ad7ff47c7e15f0d1b11248a34c254ec026fa093cac3f0a179717998ccfc63137daafafc2ff00c7a6fa39fc3a36f7f5ad73e4e78b8b94ae3593abe3a3c3ceb260d9af645d6a1886087e124fae9febce8672be1cc21c44ea583f86f195404de3e520b9f716f607bd12e3a57585f1114179cc6084db592012a8c7ae92c76f7b573ce1efb6c38a91963692456fdfa5c5c86700efcafbea1eddaa6174f269ace2a71b561f39c362c488cab2189f49561ca40a0ec0f3f2bf3f7ad5c3f8f80c93e1501d08c3406d2548e6eb1f5d2afd0f7db6a8dc619762268d0612cb22cc242d7d3b08e45373d6e085f98a1ec370c629e59230fe17856b4801b306e416ddd6fed4452ae45ab3946714a3668cbb090e2f349f1187631247229050ff00a8d7f393d95acdff00b51767196c199466132b5a393ce233c9c29b2b77b6b07dc5736caa3c4e5d98bc411a420d9d53efc64821c0f620fced5d2f3a79618256c245aa67200d2003adac9e2377b0b6e7b0e944b934d3a7176be40fe16e008e4595a69aec92bc63c260479415f37aea21adfca3bd3b2ae068311048f2cb770d2a2b237954a12b761d7cca4dbb1aa1e079f3289e71858d9efe4941fb8e6e03ee7e2041fd7a5672b5cc5e2c4458542cafe596fb589049b5c8f3100a9ff70f4aa7bb39315b3747d3e420e19c34386c10c4c03c594a3eb68ef76f35ca007b580e57fad54e6d3c698a11b007c64b39ea49242dff0011f315aff67986c4c6af292170e75060d70752fde51d2db827d3d2b6e698689715e2eb259a3761c8850a1002bdb6d47eb593f733aa37b550298807ed8e8762ccdb8fe6e5f90ab9c5675024f0e98c308afadedbf636ee56d50248d2ed2b6d210596ff00c43cdb7ad5dc19de17ed3016553642acfd159ad6f436f35cf4d5542971cf611e6b8efb3c5262039705544696db51bd88b0bef717f6ae7b0be271508f158ac69e2bf8a7a920923e449ffdaba54f8bf084b2cba0428aacb6e7c8ea07a73b5addeb9d118bc5c4c91c6234442da00d20ab39936f90fc3d6a2069a8106170cb10545e4156c7bdc037f9def4a9b848163b22b970a000c4dee2dd08e9d07a52a4cd17077515cdb28cf31389971693c9ad2368342954b2de7b5ec073a54aaba329f419e6d858d6f3aa01290b1f896f3682d72b7ed7ae3b98a0971f22bdc832b2f32365b81623716b0e54a953872fe0cb5f85f21ce7b87491963750cbf6790d9b71701483bf33b552e1f192370e48ece4b31d2c49dc8330437f75d8f7a54a943ee3d4fb32de1cda72726bc84f8cac65e5e73e0f5daa763e523348545ac70b2df617da44fbd6bdbd2f4a950ca8f7f4ff00886478e97fea4d0ea3e1fd955f4ed6d7e295d5df96d4dcbf10c71f8b4246909011b006e55af7205cfce952a01f3f5339263647c4e3a366252378820dbca1a25240f9ef54d9363a539be290b92ba6da6fb792c16c3a5ae7977acd2ab5dfc196a3771f92bb83a43263b1cee6ede25ae79d83b803daca3e828ab25c5c8f3e2919aeb1c88a82c360624623d7724d62954cf96690e11a785e7667c6dedb629c0b003eea0dec373b73351385f16ed062989dc623116360391db90deb34aa5f6547afa947c11886c4e0984e7c4064914eadee1accc0f704b37d687f353aa6c513b9531c6be88c6c547b8a54a9af7307ed8fefa63709e681c9dce83f954ec2e5904936183c6a4323961d0916b5c75e66952a18358fc828cf7071b614a1405469b0e834916a1d389757c728360b84ba8db63a5b97d4d2a55312e643c905a34ff62fe54a952a1f25c783ffd9);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clase_comprada`
--
ALTER TABLE `clase_comprada`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_dni` (`usuario_dni`);

--
-- Indices de la tabla `clase_practica`
--
ALTER TABLE `clase_practica`
  ADD PRIMARY KEY (`id_clase`),
  ADD KEY `DNI_alumno` (`DNI_alumno`),
  ADD KEY `DNI_profesor` (`DNI_profesor`),
  ADD KEY `matricula` (`matricula`);

--
-- Indices de la tabla `coche`
--
ALTER TABLE `coche`
  ADD PRIMARY KEY (`matricula`);

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id_comentario`),
  ADD KEY `DNI_usuario` (`DNI_usuario`);

--
-- Indices de la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD PRIMARY KEY (`id_pregunta`),
  ADD KEY `id_test` (`id_test`);

--
-- Indices de la tabla `resultado_test`
--
ALTER TABLE `resultado_test`
  ADD PRIMARY KEY (`ID_resultado`),
  ADD KEY `DNI_alumno` (`DNI_alumno`),
  ADD KEY `id_test` (`id_test`);

--
-- Indices de la tabla `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id_test`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`dni`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD UNIQUE KEY `Telefono` (`Telefono`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clase_comprada`
--
ALTER TABLE `clase_comprada`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `clase_practica`
--
ALTER TABLE `clase_practica`
  MODIFY `id_clase` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id_comentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `pregunta`
--
ALTER TABLE `pregunta`
  MODIFY `id_pregunta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=901;

--
-- AUTO_INCREMENT de la tabla `resultado_test`
--
ALTER TABLE `resultado_test`
  MODIFY `ID_resultado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `test`
--
ALTER TABLE `test`
  MODIFY `id_test` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clase_comprada`
--
ALTER TABLE `clase_comprada`
  ADD CONSTRAINT `clase_comprada_ibfk_1` FOREIGN KEY (`usuario_dni`) REFERENCES `usuario` (`dni`);

--
-- Filtros para la tabla `clase_practica`
--
ALTER TABLE `clase_practica`
  ADD CONSTRAINT `clase_practica_ibfk_1` FOREIGN KEY (`DNI_alumno`) REFERENCES `usuario` (`dni`),
  ADD CONSTRAINT `clase_practica_ibfk_2` FOREIGN KEY (`DNI_profesor`) REFERENCES `usuario` (`dni`),
  ADD CONSTRAINT `clase_practica_ibfk_3` FOREIGN KEY (`matricula`) REFERENCES `coche` (`matricula`);

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`DNI_usuario`) REFERENCES `usuario` (`dni`);

--
-- Filtros para la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD CONSTRAINT `pregunta_ibfk_1` FOREIGN KEY (`id_test`) REFERENCES `test` (`id_test`);

--
-- Filtros para la tabla `resultado_test`
--
ALTER TABLE `resultado_test`
  ADD CONSTRAINT `resultado_test_ibfk_1` FOREIGN KEY (`DNI_alumno`) REFERENCES `usuario` (`dni`),
  ADD CONSTRAINT `resultado_test_ibfk_2` FOREIGN KEY (`id_test`) REFERENCES `test` (`id_test`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
