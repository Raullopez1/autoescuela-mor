package com.example.ProyectoFinalTFG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalTfgApplicationTests {

	@Test
	void contextLoads() {
	}

}
