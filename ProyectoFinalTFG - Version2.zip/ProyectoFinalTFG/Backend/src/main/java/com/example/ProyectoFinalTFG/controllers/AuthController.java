package com.example.ProyectoFinalTFG.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.ProyectoFinalTFG.models.RolUsuario;
import com.example.ProyectoFinalTFG.models.Usuario;
import com.example.ProyectoFinalTFG.repository.UsuarioRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Login
    @GetMapping("/login")
    public String mostrarLogin() {
        return "view/html/login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam String dni, @RequestParam String password, Model model,
            HttpSession session) {
        try {
            Usuario usuario = usuarioRepository.findById(dni).orElse(null);
            if (usuario != null && usuario.getContraseña().equals(password)) {
                session.setAttribute("dni", dni); // Guardar el DNI en la sesión
                model.addAttribute("usuario", usuario);
                return "redirect:/dashboard";
            }
            model.addAttribute("error", "DNI o contraseña incorrectos");
        } catch (Exception e) {
            model.addAttribute("error", "Ocurrió un error al procesar el inicio de sesión. Inténtalo de nuevo.");
            e.printStackTrace();
        }
        return "view/html/login";
    }

    // Logout
    @GetMapping("/logout")
    public String cerrarSesion(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // Registro
    @GetMapping("/register")
    public String mostrarRegistro(HttpSession session, Model model) {
        String dni = (String) session.getAttribute("dni");

        Usuario usuario = usuarioRepository.findById(dni).orElse(null);
        if (usuario == null || usuario.getRol() != RolUsuario.ADMIN) {
            return "redirect:/dashboard";
        }
        return "view/html/register";
    }

    @PostMapping("/register")
    public String registrarUsuario(
            @RequestParam("dni") String dni,
            @RequestParam("nombre") String nombre,
            @RequestParam("apellido1") String apellido1,
            @RequestParam("apellido2") String apellido2,
            @RequestParam("localidad") String localidad,
            @RequestParam("edad") int edad,
            @RequestParam("rol") RolUsuario rol,
            @RequestParam("correo") String correo,
            @RequestParam("contraseña") String contraseña,
            @RequestParam("telefono") int telefono,
            @RequestParam("imagen") MultipartFile imagen,
            Model model) {

        try {
            // Crear un nuevo usuario
            Usuario usuario = new Usuario();
            usuario.setDni(dni);
            usuario.setNombre(nombre);
            usuario.setApellido1(apellido1);
            usuario.setApellido2(apellido2);
            usuario.setLocalidad(localidad);
            usuario.setEdad(edad);
            usuario.setRol(rol);
            usuario.setCorreo(correo);
            usuario.setContraseña(contraseña);
            usuario.setTelefono(telefono);

            // Guardar la imagen como un array de bytes
            if (!imagen.isEmpty()) {
                usuario.setImagen(imagen.getBytes());
            }

            // Guardar el usuario en la base de datos
            usuarioRepository.save(usuario);

            model.addAttribute("success", "Usuario registrado exitosamente.");
            return "redirect:/dashboard";
        } catch (IOException e) {
            model.addAttribute("error", "Error al procesar la imagen. Inténtalo de nuevo.");
            e.printStackTrace();
            return "view/html/register";
        }
    }

}
