package com.example.ProyectoFinalTFG.controllers;

import com.example.ProyectoFinalTFG.models.RolUsuario;
import com.example.ProyectoFinalTFG.models.Usuario;
import com.example.ProyectoFinalTFG.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import jakarta.servlet.http.HttpSession;

@Controller
public class UsuarioController {

    @Autowired
    private UsuarioRepository usuarioRepository;
 
    public RolUsuario obtenerRolUsuario(HttpSession session) {
        String dni = (String) session.getAttribute("dni");
        Usuario usuario = usuarioRepository.findById(dni).orElse(null);
        return (usuario != null) ? usuario.getRol() : null;
    }
}