package com.example.ProyectoFinalTFG;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFinalTfgApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalTfgApplication.class, args);
	}

}
