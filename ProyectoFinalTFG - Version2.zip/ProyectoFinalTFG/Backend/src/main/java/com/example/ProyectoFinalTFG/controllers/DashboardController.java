package com.example.ProyectoFinalTFG.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.example.ProyectoFinalTFG.models.RolUsuario;
import com.example.ProyectoFinalTFG.models.Usuario;
import com.example.ProyectoFinalTFG.repository.UsuarioRepository;
import jakarta.servlet.http.HttpSession;
import java.util.Base64;
import java.util.List;

@Controller
public class DashboardController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/dashboard")
    public String mostrarDashboard(HttpSession session, Model model) {
        String dni = (String) session.getAttribute("dni");
        if (dni == null) {
            return "redirect:/login"; // Redirige al login si no hay sesión
        }

        Usuario usuario = usuarioRepository.findById(dni).orElse(null);
        if (usuario != null) {
            model.addAttribute("usuario", usuario);

            // Convertir la imagen a Base64 para mostrarla en la vista
            if (usuario.getImagen() != null) {
                String imagenBase64 = Base64.getEncoder().encodeToString(usuario.getImagen());
                model.addAttribute("imagenUsuario", imagenBase64);
            } else {
                model.addAttribute("imagenUsuario", null); // Si no hay imagen, pasar null
            }

            // Número de alumnos registrados
            int numAlumnos = usuarioRepository.findByRol(RolUsuario.ALUMNO).size();
            model.addAttribute("numAlumnos", numAlumnos);

            // Número de profes registrados
            int numProfes = usuarioRepository.findByRol(RolUsuario.PROFESOR).size();
            model.addAttribute("numProfes", numProfes);

            // Número de administradores registrados
            int numAdmin = usuarioRepository.findByRol(RolUsuario.ADMIN).size();
            model.addAttribute("numAdmin", numAdmin);

            // Facturación: cada alumno paga 148,12 €
            double facturacion = numAlumnos * 148.12;
            // Formatear a dos decimales y añadir EUR
            String facturacionStr = String.format("%.2f EUR", facturacion);
            model.addAttribute("facturacion", facturacionStr);

            // Mostrar botón de registro para cada uno de los Roles
            if (usuario.getRol() == RolUsuario.ADMIN) {
                model.addAttribute("esAdmin", true);
            } else if (usuario.getRol() == RolUsuario.PROFESOR) {
                List<Usuario> alumnos = usuarioRepository.findByRol(RolUsuario.ALUMNO);
                model.addAttribute("alumnos", alumnos);
                model.addAttribute("esProfesor", true);

            } else if (usuario.getRol() == RolUsuario.ALUMNO) {
                model.addAttribute("esAlumno", true);
            }

            return "view/html/dashboard";
        }

        return "redirect:/login"; // Redirige al login si el usuario no existe
    }
}