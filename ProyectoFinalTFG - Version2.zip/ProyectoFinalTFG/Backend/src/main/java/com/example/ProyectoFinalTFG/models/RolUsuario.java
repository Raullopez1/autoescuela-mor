package com.example.ProyectoFinalTFG.models;

public enum RolUsuario {
    ALUMNO, ADMIN, PROFESOR
}
