document.addEventListener("DOMContentLoaded", function () {
    var menuHTML = `
      <!-- Barra superior -->
    <div class="top-bar">
        <div class="container">
            <div class="top-bar-left">
                <span class="brand">AUTOESCUELA MOR</span>
            </div>
            <div class="top-bar-right">
                <span class="contact-info">📞 +34 974 123 456</span>
                <a href="/login" class="login-btn">Login</a>
            </div>
        </div>
    </div>

    <!-- Menu de navegacion -->
    <nav class="menu">
        <ul>
            <li><a href="index.html">Nosotros</a></li>
            <li><a href="permiso-b.html">Permisos</a></li>
            <li><a href="contacto.html">Contacto</a></li>
            <li><a href="ubicacion.html">Ubicación</a></li>
        </ul>
    </nav>
`;

    var footerHTML = `
    <!-- Footer -->
    <footer class="footer">
        © 2023 Autoescuela MOR | 📞 +34 974 123 456 | ✉️ info@autoescuelamor.com
    </footer>
`;


    // Insertaremos el menu en el contenedoor de las clases con la clase 'menu-container'
    var menuContainer = document.querySelector(".menu-container");
    if (menuContainer) {
        menuContainer.innerHTML = menuHTML;
    }

    // Insertaremos el footer en el contenedoor de las clases con la clase 'footer-container'
    var footerContainer = document.createElement("div");
    footerContainer.innerHTML = footerHTML;
    document.body.appendChild(footerContainer);
});