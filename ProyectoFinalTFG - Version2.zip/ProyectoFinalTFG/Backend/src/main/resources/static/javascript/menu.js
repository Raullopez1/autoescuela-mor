function renderMenu(user = { name: "Usuario", photo: "https://randomuser.me/api/portraits/men/1.jpg" }) {
    // Elimina el menú anterior si existe
    document.querySelectorAll('.container').forEach(e => e.remove());

    // Crea el HTML del menú y topbar
    const container = document.createElement("div");
    container.className = "container";
    container.innerHTML = `
        <aside class="sidebar">
            <div class="logo">
                <h2>Autoescuela<br><span>Mor</span></h2>
            </div>
            <div class="menu-title">MENÚ</div>
            <nav class="menu">
                <ul>
                    <a href="/dashboard" <li data-section="Inicio">🏠 Inicio</li> </a>
                    <a href="/test" <li data-section="Test">🏫 Test</li> </a>
                    <a href="/dgt" <li data-section="DGT">💶 DGT</li> </a>
                    <a href="/calendario" <li data-section="Calendario">📚 Calendario</li> </a>
                    <a href="/mis-clases" <li data-section="Mis Clases">📝 Mis Clases</li> </a>
                    <a href="/comentarios" <li data-section="Comentarios">🧠 Comentarios</li> </a>
                    <a href="/configuracion" <li data-section="Configuración">⚙️ Configuración</li> </a>
                    <a href="/logout" <li data-section="Cerrar sesión">🔒 Cerrar sesión</li> </a>
                </ul>
            </nav>
        </aside>
        <div class="main-content">
            <header class="topbar">
                <div class="migas">
                    Autoescuelamor <span class="flecha">›</span> <span class="miga-actual">Inicio</span>
                </div>
                <div class="user-info">
                    <span class="username">${user.name}</span>
                    <img class="perfil-icono" src="${user.photo}" alt="Foto de usuario" style="width:32px;height:32px;border-radius:50%;border:2px solid #3f8343;background:#fff;">
                </div>
            </header>
            <main class="content-area">
                <!-- Aquí va el contenido principal -->
            </main>
        </div>
    `;
    document.body.appendChild(container);

    // Añade eventos para actualizar las migas
    container.querySelectorAll('.menu li').forEach(li => {
        li.addEventListener('click', function () {
            const seccion = this.getAttribute('data-section');
            const migaActual = container.querySelector('.miga-actual');
            if (migaActual) {
                migaActual.textContent = seccion;
            }
        });
    });
}

// Llama a esta función al cargar la página
document.addEventListener("DOMContentLoaded", function () {
    // Si tienes window.usuarioMenu, pásalo aquí
    renderMenu(window.usuarioMenu || undefined);
});